import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Day_1{
    public int i;
    public String text;
    public JTextArea ta;

    public Day_1(JTextArea t){
        ta = t;
    }

    public void Intro(){
        i = 0;
        text = "Inner Voice (IV): “Welcome to Texas A&M University, where sanity goes to die!!!”"
                + "\n" +
                "\n" +
                "IV: “Who am I? Why, I am your own personal Inner Voice! Every good college student has one."
                + "\n" +
                "The crazy people are the ones that don’t talk to themselves, but just to be safe let’s keep all of "
                + "\n" +
                "our conversations on the down low. We would still like to get you some real friends eventually.”"
                + "\n" +
                "\n" +
                "IV: “Anyway, let’s get down to business. Your job as a college student is to survive. To do that, "
                + "\n" +
                "you will have to become a management master. If you could please avert your attention "
                + "\n" +
                "downward, you will see a set of meters. One measures your overall preparedness and the other "
                + "\n" +
                "measures your sanity. Depending on what choices you make, these values will go up and down."
                + "\n" +
                "Life is like a rollercoaster as they say.”"
                + "\n" +
                "\n" +
                "IV: “You should consider yourself lucky. Not everyone gets to see such valuable information in "
                + "\n" +
                "such an organized manner. Most people just work themselves too hard until it is too late. But "
                + "\n" +
                "that’s enough with the doom and gloom. Classes start tomorrow, so let’s start with a simple "
                + "\n" +
                "decision to mark your first step at college.”"
                + "\n" +
                "\n" +
                "Go to your dorm. (Choice 1)"
                + "\n" +
                "Take a walk around campus. (Choice 2)"
                ;
        timer.start();
        ta.append("\n");
        //text = "IV: “Who am I? Why, I am your own personal Inner Voice! Every good college student has one." +"\n" + "The crazy people are the ones that don’t talk to themselves, but just to be safe let’s keep all of" + "\n" + "our conversations on the down low. We would still like to get you some real friends eventually.”";
    }

    Timer timer = new Timer(50, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            char character[] = text.toCharArray();
            int array_size = character.length;

            String char_to_add = "";
            String blank = "";

            char_to_add = blank + character[i];
            ta.append(char_to_add);

            i++;

            if(i == array_size){
                i = 0;
                timer.stop();
            }
        }
    });
}