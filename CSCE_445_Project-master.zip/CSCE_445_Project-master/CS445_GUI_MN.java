import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;


/*Day 1 = gameState 0, Day 2 = gameState 6, Day 3 = gameState 19, Day 4 = gameState 25, Day 5 = gameState 30, Day 6 = gameState 40
* */
public class CS445_GUI_MN extends JFrame implements ActionListener {
    JPanel top_panel, bot_panel, labels_panel, choiceButtons_panel, logAndButtons_panel;
    JTextPane pane;
    JScrollPane pane2;
    JLabel log_label, p_label, s_label;
    ImageIcon start;
    JTextArea notebook;
    JButton ch_1, ch_2;
    JTextArea prep, sanity;
    JProgressBar p_bar, s_bar;
    protected int gameState=0;
    int san = 50;
    int preparedness = 10;
    boolean exploredCampus = false;
    File myObj = new File("savedState.txt");
    Scanner myReader;
    String paneText = "";
    boolean robbed = false;
    boolean resisted = false;
    boolean copsCalled = false;
    boolean friend = false;
    boolean member = false;
    String savedState = san + ", " + preparedness + ", " + gameState + ", " + exploredCampus + ", " + robbed + ", " + resisted + ", " + copsCalled + ", " + friend + ", " + member;
    String data = savedState;



    public CS445_GUI_MN() throws IOException {
        //JFrame main_frame = new JFrame("School of Hard Choices");

        top_panel = new JPanel();
        bot_panel = new JPanel(new BorderLayout());
        labels_panel = new JPanel();
        choiceButtons_panel = new JPanel();
        logAndButtons_panel = new JPanel();
        logAndButtons_panel.setLayout(new BoxLayout(logAndButtons_panel, BoxLayout.Y_AXIS));



        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        //game screen
        start = new ImageIcon("D:\\CSCE\\CSCE_445_Project\\game_menu.png");
        pane = new JTextPane();
        pane.setBounds(50, 50, 600, 600);
        pane.setBackground(Color.black);
        pane.setForeground(Color.white);
        pane.setText("Start (choice 1)\nLoad Saved State (choice 2)");
//        pane.setContentType("text/html");
//        pane.setText("<html><b>Start (Choice 1)</b><br><br><b>Quit (Choice 2)</b></html>");
        pane.setEditable(false);
        pane2 = new JScrollPane(pane);
        pane2.setPreferredSize(new Dimension(600, 600));

        //game log
        log_label = new JLabel("Log");
        notebook = new JTextArea(35,20);

        //buttons
        ch_1 = new JButton("Choice 1");
        ch_2 = new JButton("Choice 2");
        ch_1.addActionListener(this);
        ch_2.addActionListener(this);

        //Resources
        p_label = new JLabel("Preparedness");
        prep = new JTextArea(1,5);
        p_bar = new JProgressBar();
        p_bar.setValue(preparedness);
        prep.setEditable(false);
        prep.setText(preparedness + "/100");

        s_label = new JLabel("Sanity");
        sanity = new JTextArea(1,5);
        s_bar = new JProgressBar();
        s_bar.setValue(san);
        sanity.setEditable(false);
        sanity.setText(san + "/100");


        choiceButtons_panel.add(ch_1);
        choiceButtons_panel.add(ch_2);

        logAndButtons_panel.add(log_label);
        logAndButtons_panel.add(notebook);
        logAndButtons_panel.add(choiceButtons_panel);

        top_panel.add(pane2, BorderLayout.CENTER);
        top_panel.add(logAndButtons_panel, BorderLayout.CENTER);

        labels_panel.add(p_label);
        labels_panel.add(p_bar);
        labels_panel.add(prep);
        labels_panel.add(s_label);
        labels_panel.add(s_bar);
        labels_panel.add(sanity);

        bot_panel.add(labels_panel, BorderLayout.CENTER);

        try {
//            File myObj = new File("savedState.txt");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }


        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                savedState = san + ", " + preparedness + ", " + gameState + ", " + exploredCampus + ", " + robbed + ", " + resisted + ", " + copsCalled + ", " + friend + ", " + member + ", " + pane.getText();
                //System.out.println(savedState);
                try {
                    FileWriter myWriter = new FileWriter("savedState.txt");
                    myWriter.write(savedState);
                    myWriter.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                System.exit(0);
            }
        });


        add(top_panel,BorderLayout.PAGE_START);
        add(bot_panel,BorderLayout.CENTER);
        setSize(screenSize.width,screenSize.height);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
    {
        if (gameState== 0) {
            if (e.getSource() == ch_1) {//Day 1
                pane.setText("Intro/Tutorial:\n" +
                        "Days Till Midterm: 30\n" +
                        "Day 1: Sunday\n" +
                        "Inner Voice (IV): “Welcome to Texas A&M University, where sanity goes to die!!!”" +
                        "\n" +
                        "IV: “Who am I? Why, I am your own personal Inner Voice! \nEvery good college student has one. The crazy people are the ones that don’t talk to themselves, but just to be safe let’s keep all of our conversations on the down low. We would still like to get you some real friends eventually.”\n" +
                        "\n" +
                        "IV: “Anyway, let’s get down to business. Your job as a college student is to survive. To do that, you will have to become a management master. If you could please avert your attention downward, you will see a set of meters. One measures your overall preparedness and the other measures your sanity. Depending on what choices you make, these values will go up and down. Life is like a rollercoaster as they say”\n" +
                        "\n" +
                        "IV: “You should consider yourself lucky. Not everyone gets to see such valuable information in such an organized manner. Most people just work themselves too hard until it is too late. But that’s enough with the doom and gloom. Classes start tomorrow, so let’s start with a simple decision to mark your first step at college.”\n" +
                        "\n" +
                        "What would you like to do?\n" +
                        "Go to your dorm. (Choice 1)\n" +
                        "Take a walk around the campus. (Choice 2)\n");
                gameState++;
            }
            if (e.getSource() == ch_2) {
//                    System.out.println("2");
                //System.out.println(myObj.canRead());
                try {
                    myReader = new Scanner(myObj);
                } catch (FileNotFoundException fileNotFoundException) {
                    fileNotFoundException.printStackTrace();
                }
                data = "";
                while(myReader.hasNextLine()) {
//                        System.out.println("1");
                    data += myReader.nextLine() + "\n";
                    //System.out.println(data);
                }
                myReader.close();
                //System.out.println(data);
                //System.out.println("3");
                myReader.close();
                String[] info = data.split(", ");
                san = Integer.parseInt(info[0]);
                preparedness = Integer.parseInt(info[1]);
                int GS = Integer.parseInt(info[2]);
                exploredCampus = Boolean.parseBoolean(info[3]);
                robbed = Boolean.parseBoolean(info[4]);
                resisted = Boolean.parseBoolean(info[5]);
                copsCalled = Boolean.parseBoolean(info[6]);
                friend = Boolean.parseBoolean(info[7]);
                member = Boolean.parseBoolean(info[8]);
                for(int i = 0; i < GS; i++) {
                    gameState++;
                }
                for(int i = 9; i < info.length; i++) {
                    paneText = paneText + info[i] + ", ";
                }
//                    System.out.println(Arrays.toString(info));
//                    System.out.println(paneText);
                paneText = paneText.substring(0, paneText.length()-2);
                pane.setText(paneText);
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);

//                    System.out.println("San: "  + san + ", Prep: " + preparedness + ", GS: " + gameState + ", EC: " + exploredCampus);
            }
        } else if (gameState== 1) {
            if (e.getSource() == ch_1) {
                pane.setText("You make your way to your dorm which is on the fourth floor of the Appelt Residence Hall. It is an adequately sized room with two full sized beds against the wall. These beds are raised, almost like bunks beds, with desks underneath. There is a closet on the far wall next to the only window. Your bed is closest to the door. A 32-inch television sits on top of a mini fridge against the wall across from the beds. Aside from that, the room is pretty empty.\n" +
                        "\n" +
                        "Your Dorm:\n" +
                        "Days Till Midterm: 30\n" +
                        "IV: “So, you are more of the introverted type. Don’t worry, I don’t get out much either. Well, since you are here, why don’t you at least talk to your new roommate? The only associating you did with them was exchanging names back at move-in and it is now my job to inform you that we do not even remember that.”\n" +
                        "\n" +
                        "IV: “Hey, don’t get upset at me! How was I supposed to remember? We were super busy that day with moving and the … um ... uh ... Well, the why doesn’t really matter. What does matter is your roommate could come in any minute and you don’t even know their name.”\n" +
                        "\n" +
                        "IV: “Who knows? Maybe they won’t remember your name either … or maybe they will. Man, wouldn’t that be awkward. So, do we face the possible embarrassment or do we adopt the college mindset now and just push that problem to another day? Personally, I think it’s much better to at least know the name of the stranger you are going to be sharing a small room with, but what do I know? I’m just you.”\n" +
                        "\n" +
                        "What would you like to do?\n" +
                        "Wait for the roommate. (Choice 1)\n" +
                        "Avoid the roommate. (Choice 2)\n");
                gameState=3;
            }
            if (e.getSource() == ch_2) {
                san += 5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                pane.setText("You check out the buildings where all of your classes are going to be held, making sure to note their locations and how you got there for the future. With it still being August in Texas, you grow very tired from the heat and decide to rest on a bench under a large tree in the middle of campus. You decide to rest your eyes for a moment, but you end up drifting asleep until you are awoken by a female voice.\n" +
                        "\n" +
                        "Unknown Woman (UW): “You’re either not very superstitious or you’re a Freshman.”\n" +
                        "\n" +
                        "Still half-dazed from just being woken up, all you can do is stare at the unusual girl.\n" +
                        "\n" +
                        "UW: “Well, that stupid look you’re giving me definitely suggests the latter and if that’s the case, that also means you don’t know the legend behind that tree you got a little too comfortable under. Since it’s already too late, I guess I get the pleasure of telling you that you’re probably going to die alone because that’s the local legend for that tree. If you walk under it alone, you die alone.”\n" +
                        "\n" +
                        "You continue to stare in confusion.\n" +
                        "\n" +
                        "UW: “Still with the dumb look huh? Are you sure you belong at this college? Anyway, since you’re a Freshman, how about you do me a favor and take one of these.”\n" +
                        "\n" +
                        "The girl hands you a brochure.\n" +
                        "\n" +
                        "UW: “Our org lost a lot of members last semester, so it’s my job to scout out new meat. If you want something better to do with your time than just sleeping under cursed trees, then come to our booth at Open House.”\n" +
                        "\n" +
                        "The girl quickly takes her leave and you decide to head back to your dorm before the sun goes down.\n\n" +
                        "Click any button to continue.");
                exploredCampus = true;
                gameState++;
            }
        } else if (gameState== 2) {
            if(e.getSource() == ch_1 || e.getSource() == ch_2) {
                pane.setText("Your Dorm:\n" +
                        "Days Till Midterm: 30\n\n" +
                        "As you enter your dorm room you notice that the lights are off and your roommate is already asleep. As to not wake them, you close the door very carefully and quietly make your way to your bed.\n" +
                        "\n" +
                        "IV: “ That was a pretty eventful day if I do say so myself. We scoped out the campus, ate at Chick-fil-a, confirmed a future of loneliness, had a great nap, and made a new friend; even though we didn’t even get her name. But hey, there’s always tomorrow right? Speaking of, since tomorrow isn’t here yet, what do you want to do before bed?”\n" +
                        "\n" +
                        "What would you like to do?\n\n" +
                        "Study. (Choice 1)\n" +
                        "Relax. (Choice 2)\n");
                gameState=5;
            }
        }
        else if (gameState== 3) {
            if(e.getSource() == ch_1) {
                friend = true;
                pane.setText("You lay in bed on your phone for roughly 30 minutes. Suddenly, you hear the door open and you quickly sit up to see who entered and it was, in fact, your roommate. Your roommate didn’t have any unique characteristics. Green eyes and short brown hair were the only traits you took the time to acknowledge. Although, you do notice the backwards cap with the name Riley on the velcro band. Latching on to this information, you immediately greet your roommate using the name on the cap, but this is only met with a confused stare.\n" +
                        "\n" +
                        "Roommate: “Riley? Why are you calling me by my brother’s name? How do you know my brother’s name? My my my...not even 5 minutes together and we are already mentally linked.”\n" +
                        "\n" +
                        "After a few seconds of excruciating awkward silence, the roommate’s eyes glance up and flash with realization.\n" +
                        "\n" +
                        "Roommate: “Ohhhhhh. The hat. Yeah, my brother gave this to me. Told me it was so I wouldn’t forget him or some noise. He’s like 6 years old. Anyway, my name’s Alex, since I’m assuming that little mistake means you didn’t know my name.”\n" +
                        "\n" +
                        "Alex: “Don’t worry about it too much. I didn’t really expect you to remember it. Plus, I’m pretty used to people forgetting my name. Actually, I’m used to people just ignoring me entirely, but that just reminds me to keep my real friends close.”\n" +
                        "\n" +
                        "Alex: “Speaking of, how about we exchange numbers? Then we can officially call each other friends.”\n" +
                        "\n" +
                        "You exchange numbers with Alex and you both go on with your days.\n\nPress any button to continue");
                gameState++;
                san += 5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
            }
            if(e.getSource() == ch_2) {
                pane.setText("Not wanting to get found by your roommate, you simply go to your local McDonalds, have a meal, and chill out scrolling through your phone. At around 9:00 p.m., your phone is on its last few percent and you are growing extremely bored. So, you finally decide to head back to your dorm to go to sleep.\n" +
                        "\n" +
                        "As you carefully open the door to your dorm, you notice that the lights are off. Lucky for you, your roommate is already asleep. You slowly make your way to your bed.\n" +
                        "\n" +
                        "IV: “You know, with all of these antisocial tendencies, maybe your roommate should worry about you being some psycho.”\n" +
                        "\n" +
                        "IV: “I’m sorry. Today was just soooo boring and you know I can get irritable without stimulation. Maybe you should try actually doing something tomorrow. I’m just saying that your current decisions can’t possibly be going anywhere fruitful.”\n" +
                        "\n" +
                        "IV: “Whatever. I’m too tired at this point to care and you spent too long trying to avoid your roommate that there isn’t really any time to do anything else. Besides, you would probably just risk waking them up. And I assume that is not what you want. So, let’s just go to bed.”\n\nPress any button to continue...");
                gameState= 6;
            }
        }
        else if (gameState== 4) {
            if(e.getSource() == ch_1 || e.getSource() == ch_2){
                pane.setText("After exchanging numbers with Alex, you climb into your bed to relax with your thoughts for a second.\n" +
                        "\n" +
                        "IV: “Well, certainly not the deranged killer I had in mind, but I guess Alex is alright. Oh well. Maybe we will come across that lunatic killer later. I thought you were totally screwed after the whole name on the hat fiasco. It’s a good thing you aren’t in college with the hopes of becoming a detective.”\n" +
                        "\n" +
                        "IV: “All joking aside. There’s not really enough time to go out and do anything now, but there’s plenty of time to do something here. So, what do you say?”\n" +
                        "\n" +
                        "Study (Choice 1)\n" +
                        "Play video games (Choice 2)\n");
                gameState++;
            }
        }
        else if (gameState== 5) {
            if (e.getSource() == ch_1) {
                pane.setText("You studied. \n\nPress any button to continue...");
                san -= 5;
                preparedness += 5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
            }
            if (e.getSource() == ch_2) {
                pane.setText("You relax and then go to sleep. \n\nPress any button to continue...");
                san += 5;
                preparedness -= 5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
            }
            gameState++;
        }
        else if (gameState== 6) { //Day 2
            if (e.getSource() == ch_1 || e.getSource() == ch_2) {
                pane.setText("Days till Midterm: 29\n" +
                        "Day Two, Monday, First Morning:\n\n" +
                        "IV: “HEY...WAKE...UP!!!”\n\n" +
                        "You wake up in a haze. There is a loud noise violating your ears which you slowly realize is your phone's alarm. You also notice that the dorm room is still dark as the sun is only beginning to rise. After stretching and rubbing your eyes, you lean up from your bed and shut off the alarm\n" +
                        "IV: “Thank goodness! That alarm was really getting on my nerves. Anyway good morning Sleeping Beauty. I'm so glad we didn't need the intervention of a Prince Charming to get you up. That being the case, you still look and, probably, feel like death. Nevertheless, it is currently 7:00 AM and our official first day of college. So, what do you want to do?”\n\n" +
                        "IV: “Being a Freshman, you were lucky enough to get 8:00 AM classes every day this week. Now you could of course go to class..., or you could go right back to bed and just go to your later classes. I mean, it's just the first day. Those classes are usually just used to go over the syllabus, so it shouldn't be any harm to catch some extra Zs and just go over it later. As always its your choice”\n\n" +
                        "What would you like to do?\n\n" +
                        "Go to class. (Choice 1)\n" +
                        "Sleep In. (Choice 2)\n");
                gameState++;
            }
        }
        else if (gameState== 7) {
            if (e.getSource() == ch_1) {
                if (exploredCampus) {
                    pane.setText("First Class of the Day:\n" +
                            "Days till Midterm: 29\n\n" +
                            "After a few minutes of deep consideration, you slowly pull yourself out of the warm comfort of your bed. You perform your morning routine, grab your backpack, and head out the door. As you step outside of the dormatorium, you quickly notice the unbearable humidity of this Texas morning and rush to class.\n\n" +
                            "After a short walk, you find yourself in front of the Math Department and head inside. With the AC running, the building was much cooler than it was outside. It was comfortable even. You briskly head to the third floor of the building, enter the room and take a seat in the middle of the class. You wait quietly until 8:00 AM. The room promptly fills with other students and an older gentleman, which you assume to be the professor, walks to the front of the lecture hall.\n\n" +
                            "Professor: “Good morning. My name is Dr. Ulan Oblonsky and I will be your Calculus 1 professor.”\n\n" +
                            "The man appeared to be in his late 50s. He is rather heavyset. As for hair, the top of his head reflected the fluorescent lighting of the room, but he does have a thick white beard. The only thing thicker than his beard is his accent. It sounded Russian.\n\n" +
                            "Dr Oblonsky: “Allow me to congratulate you all for showing up. I know it is very early, but many would just say there is no need to come on the first day or week even. Something about syllabus week. I do not approve of such attitudes. Which is why I have a big quiz on Friday morning in class.Some of you may be panicking and wondering how big this quiz is going to be. Well, you are right to worry.”\n" +
                            "\n" +
                            "Dr. Oblonsky: “This quiz will be worth 10 percent of your final grade. To some of you Freshman, that may not seem like a lot, but trust me when I say that 10 percent may make or break you at the end of the semester. So, you better come to class this week and study when you can.”\n" +
                            "\n" +
                            "Dr. Oblonsky: “On that note, let’s get started…”\n\n" + "Click any choice button to continue");
                    preparedness += 5;
                    prep.setText(preparedness + "/100");
                    p_bar.setValue(preparedness);
                    gameState=13;
                } else {
                    pane.setText("First Class of the Day:\n" +
                            "Days till Midterm: 29\n\n" +
                            "After a few minutes of deep consideration, you slowly pull yourself out of the warm comfort of your bed. You perform your morning routine, grab your backpack, and head out the door. As you step outside of the dormatorium, you quickly notice the unbearable humidity of this Texas Morning and take your first steps to hurry to class. However after about five minutes you notice something terrible. You have no idea how to get to class.\n\n" +
                            "IV: “Are you sure that you belong in college? I mean, come on, getting lost on the first day! That takes a special kind of stupid. Now quit your panicking. Luckily you live in the digital age, so just check your cell phone.”\n\n" +
                            "Feeling even dumber than before, you violently reach for your front pocket. Suddenly, you realize the true misfortune of your situation as you realize that in your haste, you managed to leave your phone in the dorm." + "\n\n" +
                            "IV: “You know. When you breathe, you're supposed to let the air out, not just let it take up space in your head. And don't go trying to blame this on me! We both know I'm useless until at least noon. Anyway, by the time we get back to the dorm, get your phone, and find the building, class will basically be over. I guess you could do the lame thing and ask for help. Look! There are two upstanding citizens now.”\n\n" +
                            "Ahead of you, you see two people. One of them is a guy leaning against a building on his phone. The other person is a girl sitting at a bench reading a book. Who do you ask for help?\n\n" +
                            "The Guy(Choice 1)\n" +
                            "The Girl(Choice 2)\n");
                    san -= 5;
                    sanity.setText(san + "/100");
                    s_bar.setValue(san);
                    gameState++;
                }
            }
            if(e.getSource() == ch_2)
            {
                pane.setText("You finally wake up around 12:00 p.m. Any idea of going to class at this point is long gone. You lean up and rub your eyes furiously. After letting your vision adjust, you get out of bed and ponder on what to do next.\n" +
                        "\n" +
                        "IV: “I always thought sleep was supposed to be good for you, but I feel like crap right now. Seriously, how can you be more tired after a nap? Not to mention the dizziness and nausea. Maybe this is some kind of punishment from above for sloth.”\n" +
                        "\n" +
                        "IV: “Well, whatever, I’m almost over it. Anyway, we basically already wasted most of the day, so what do you want to do now? Wanna keep slacking or actually try to learn something on your first day of classes?\n\n" +
                        "Study(Choice 1)\n" +
                        "Keep Slacking(Choice 2)");
                gameState= 16;
            }
        }
        else if(gameState== 8)
        {
            if(e.getSource() == ch_1)
            {
                pane.setText("You approach the guy leaning against the building. Upon closer inspection, you notice he seems older than you. He has brown, scraggly hair that reaches to his shoulders and a beard which is equally brown and unkempt. You carefully get his attention. He looks up briefly from his phone to acknowledge you but just as quickly goes back to scrolling.\n\n" +
                        "Bearded Guy: “What do you want? I'm kind of busy studying if you couldn't tell.”\n\n" +
                        "His comment was harsh with a hint of sarcasm to indicate that he simply doesn't want to talk to you. Nevertheless, you sheepishly ask him for directions to the Math Department. You do, however, stress that you are in a hurry and currently running late for Calculus.\n\n" +
                        "Immediately following your plea for help, the man puts down his phone and looks at you with a sorrowful expression.\n\n" +
                        "Bearded Guy: “Did you say you were running late for Calculus? I hope you don't have Dr. Oblonsky. That man definitely has a stick up his ass. Many a freshman have had to change their degree because of that fossil. So yeah, I'll help you out. Anything for a troubled Freshman in need. Follow me.”\n\n" +
                        "You follow the man for a little over 10 minutes until you begin to notice the ominous tone of your surroundings. You have been led into a dark area between two buildings. There is no one around as morning classes have already started. You begin to grow uneasy and slowly attempt to back out of the alley, but before you can get too far the man suddenly pins you to the building wall. You take a breath to scream, but he firmly places a hand over your mouth before you could exhale. You then notice his other hand reaching for his back pocket. The man promptly pulls out a knife and presses it to your neck.\n\n" +
                        "Bearded Man: “Okay. Here is what's gonna happen.”\n\n" +
                        "His voice was quiet yet threatening.\n\n" +
                        "Bearded Man: “You're going to SLOWLY pull out your wallet and drop it on the ground. If you reach too fast, pull out something other than money, or do anything That I just don't like... Well, let's just say you're going to be late for a lot more than classes.”\n\n" +
                        "Following his threat, he began to press the knife harder against your skin. You could feel blood begin to run down your neck. What do you do?\n\n" +
                        "Do what he says(Choice 1)\n" +
                        "Resist(Choice 2)\n");
                san -= 1;
                preparedness -= 6;
                s_bar.setValue(san);
                p_bar.setValue(preparedness);
                sanity.setText(san + "/100");
                prep.setText(preparedness + "/100");
                gameState++;
            }
            if(e.getSource() == ch_2)
            {
                pane.setText("You approach the girl sitting on the bench. Her hair was red and it was currently up in a ponytail. She also has glasses, but they are sitting on her head as she intensely reads her novel. She seems extremely focused on the book in front of her. So much so that you almost leave her be. However, your current situation gives no time for backtracking. You slowly put your hand up and speak to get the girls attention. She doesn't look up at first, but after a moment or two she quickly lifts her head and smiles.\n\n" +
                        "Bench Girl: “I'm so sorry, but I really needed to get through that section first. How can I help you?”\n\n" +
                        "Her voice was soft and sincere. For a moment you even forgot why you were so panicked, but only for a moment. First, you apologize for interrupting her reading. Then you quickly ask for directions to the Math Department. The question seemed to puzzle the girl. She then begins to giggle.\n\n" +
                        "Bench Girl: “Please forgive me for laughing, but you are so obviously a Freshman. I believe the building you are looking for is the large, brick building behind you; the one with the guy leaning against it on his phone.”\n\n" +
                        "As you look behind you, you very clearly see a sign next to the building indicating that it is, indeed, the Math Department. You shamefully cover your face in embarassment and apologize to the girl for the trouble.\n\n" +
                        "Bench Girl: “It's no trouble. We've all been there at one time or another, but you should really try to hide that Freshman ignorance. Some people may try to take advantage of it.”\n\n" +
                        "Nodding your head, you kindly thank the girl for the help and swiftly make your way to class. \n\nPress any button to continue....");
                san += 1;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                gameState = 13;
            }
        }
        else if(gameState== 9)
        {
            if(e.getSource() == ch_1)
            {
                pane.setText("Very carefully, you pull your wallet out and drop it on the ground as you were instructed to. The man then removes his hand from your mouth to reach for the wallet. He looks away from you momentarily to retrieve your wallet, but with the knife still digging into your neck, you are far too scared to try anything.\n\n" +
                        "After picking up the wallet, the thief opens it and intensely studies its contents. Finally, he pulls the cash out with his teeth, drops the wallet back on the ground, and examines the bills with a disappointed look on his face.\n\n" +
                        "Bearded Man: “Only 25 dollars?! This is what I get for robbing a college student. Whatever...”\n\n" +
                        "He violently crams the cash into his front pocket and looks back at you.\n\n" +
                        "Bearded Man: “Alright. We're done here, but if you try anything or if I find out you called the cops on me, I'll be coming for you.”\n\n" +
                        "He quickly shoves the knife back into his pocket and runs away before you can even react. Once you are certain the man is gone, you run away as well. You sprint nonstop for 5 minutes until you are back to an area with other people. You look back, but you don't see the man. You are safe.\n\nClick any choice button to continue...");
                san = 0;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                preparedness -= 5;
                p_bar.setValue(preparedness);
                prep.setText(preparedness + "/100");
                robbed = true;
                gameState++;
            }
            if(e.getSource() == ch_2)
            {
                pane.setText("Very carefully, you pull your wallet out and drop it on the ground as you were instructed to. The man the removes his hand from your mouth to reach for the wallet. He looks away from you momentarily to retrieve you wallet. After picking up the wallet, the thief opens it and intensely studies its contents. In that moment when his attention was away from you, you pick up your foot and violently drive it into the man's stomach with a swift and violent kick using the wall for support.\n\n" +
                        "The man exhales all of the air from his body and tumbles backwards. As soon as he hits the ground, you rapidly pick your wallet off the ground and bolt for safety. You sprint nonstop for 5 minutes until you are back to an area with other people. You look back, but you don't see the man. You got away.\n\nPress any button to continue");
                san = 0;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                preparedness -= 2;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                resisted = true;
                gameState++;
            }
        }
        else if(gameState== 10)
        {
            if(e.getSource() == ch_1 || e.getSource() == ch_2) {
                pane.setText("Once you finally catch your breath, you look around to evaluate your situation and try to figure out what to do next.\n\n" +
                        "IV: “I know your first day of college is supposed to be scary, but that was a little overkill. To think, you were almost killed over 25 dollars. That would have been embarrassing, but forget about that. What do we do now. The way I see it, we can either go back to the dorm and get your phone to call the cops... or we can just put this whole thing behind us and get back to the normal, BORING college lifestyle, where the worst thing you have to worry about is bad grades from the class you missed.”\n\n" +
                        "IV: “You heard me right? I said go back to your dorm for your phone. Most people in your predicament would look for the nearest available phone, even if it's from a stranger. But, quite frankly, I'm surprisingly a little done with asking strangers for help. So do we call the cops or not?”\n\n" +
                        "Call the Cops(Choice 1)\n" +
                        "Let it go(Choice 2)\n");
                gameState++;
            }
        }
        else if(gameState== 11)
        {
            if(e.getSource() == ch_1)
            {
                pane.setText("Once you reach your dorm you search frantically for your phone and after a few minutes of looking, you find it on the bathroom counter. You unlock the phone and quickly dial 911. The operator answers almost immediately and asks about the emergency. It was a man's voice. It was stale and robotic.\n\n" +
                        "You tell the operator everything about the attack. Your recount every detail you can remember about the thief, as well as the location of alley. Once you finish explaining, the operator asks if you are okay, to which you reply that you are fine and that you do not require an ambulance.\n\n" +
                        "The operator then informs you that the report has been filed and that he will be sending officers shortly to survey the scene and follow up with you. Later that evening, two officers arrive and you spend the rest of the day speaking with them about the attack. After they leave, you decide to just go to bed as there really isn't time to do anything else. \n\nPress any button to continue");
                copsCalled = true;
                san += 10;
                preparedness -= 2;
                s_bar.setValue(san);
                p_bar.setValue(preparedness);
                sanity.setText(san + "/100");
                prep.setText(preparedness + "/100");
                gameState=19;
            }
            if(e.getSource() == ch_2)
            {
                if(e.getSource() == ch_1 || e.getSource() == ch_2) {
                    pane.setText("After a calm walk back to your dorm, you plummet into bed; feeling completely drained.\n\n" +
                            "IV: “Look. Today may not have started very great, so to speak, but there is still some time before you have to go to sleep. Is there anything you want to do to try to get your mind off what just did NOT happen?”\n\n" +
                            "Study(Choice 1)\n" +
                            "Play a Videogame(Choice 2)\n");
                    gameState++;
                }
            }
        }
        else if(gameState== 12) {
            if(e.getSource() == ch_1)
            {
                pane.setText("Yay! You studied! After studying, you go to bed.\n\nClick any button to continue...");
                san -= 2;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                preparedness += 5;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                gameState=19;
            }
            if(e.getSource() == ch_2)
            {
                pane.setText("You had a great time playing video games. After that, you go to sleep.\n\nClick any button to continue...");
                san += 5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                gameState=19;
            }
        }
        else if(gameState == 13){
            if(e.getSource() == ch_1 || e.getSource() == ch_2) {
                pane.setText("After a short walk, you find yourself in front of the Math Department and head inside. With the AC running, the building was much cooler than it was outside. It was comfortable even. You briskly head to the third floor of the building, enter the room and take a seat in the middle of the class. You wait quietly until 8:00 a.m. The room promptly fills with other students and an older gentleman, which you assume to be the professor, walks to the front of the lecture hall.\n" +
                        "\n" +
                        "Professor: “Good morning. My name is Dr. Ulan Oblonsky and I will be your Calculus 1 professor.”\n" +
                        "\n" +
                        "The man appeared to be in his late 50s. He is rather heavyset. As for hair, the top of his head reflected the fluorescent lighting of the room, but he does have a thick white beard. The only thing thicker than his beard is his accent. It sounded Russian.\n" +
                        "\n" +
                        "Dr. Oblonsky: “Allow me to congratulate you all for showing up. I know it is very early, but many would just say there is no need to come on first day or week even. Something about syllabus week. I do not approve of such attitudes. Which is why I have a big quiz on Friday morning in class. Some of you may be panicking and wondering how big this quiz is going to be. Well, you are right to worry.”\n" +
                        "\n" +
                        "Dr. Oblonsky: “This quiz will be worth 10 percent of your final grade. To some of you Freshman, that may not seem like a lot, but trust me when I say that 10 percent may make or break you at the end of the semester. So, you better come to class this week and study when you can.”\n" +
                        "\n" +
                        "Dr. Oblonsky: “On that note, let’s get started…”\n\nPress any button to continue...");
                preparedness += 5;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                gameState++;
            }
        }
        else if(gameState== 14)
        {
            if(e.getSource() == ch_1 || e.getSource() == ch_2) {
                pane.setText("After the longest 50 minutes of your life, Calculus finally ends and you are allowed to leave. You then go to your two other classes of the day, but nothing notable happened. It is now 12:30 pm and you are now setting under a tree relaxing and eating your lunch, a peanut butter sandwich.\n\n" +
                        "IV: “Please don't think too loud. I'm currently experiencing an information hangover. UGH!!! I was never meant to work this hard and that Mr. Oblonsky was the worst part.”\n\n" +
                        "IV: “I mean seriously! Giving a quiz like that in the first week should be illegal... RIGHT!? Not to mention the material he covered was so high level that I was fried before the class was halfway over. Then we had other classes after that. At one point I couldn't even understand one of your professors. They were basically speaking another language. Oh wait... That was Spanish class.”\n\n" +
                        "Anyway, now that classes are over for the day, let's go have some fun and unwind. Or if you really hate me, I guess we could go start studying for that quiz.\n\n" +
                        "Go to dorm and study(Choice 1)\n" +
                        "Go have fun(Choice 2)\n");
                preparedness += 2;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                gameState++;
            }
        }
        else if (gameState== 15) {
            if (e.getSource() == ch_1) {
                pane.setText("You went to the dorm and studied. After that, you went to sleep.\n\nPress any button to continue...");
                san -= 2;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                preparedness += 5;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                gameState=19;
            }
            if (e.getSource() == ch_2) {
                pane.setText("You went out and had fun. After that, you went to sleep.\n\nPress any button to continue...");
                san += 5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                gameState=19;
            }
        }
        else if (gameState== 16) {
            if(e.getSource() == ch_1) {
                pane.setText("You spend the rest of the day studying. After that, you go to sleep.\n\nPress any button to continue...");
                san -= 2;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                preparedness += 5;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                gameState=19;
            }
            if (e.getSource() == ch_2) {
                if(friend) {
                    pane.setText("With nothing else to do, you decide to check out the recreational room in your dorm. Once there, you are taken aback by everything they had to offer. There were TVs on every wall for video games, pool tables, ping pong tables, and board games. Then, while you were scoping out the place, you notice someone waving excitedly at you. Focusing your gaze, you see that it is Alex. Immediately, you wave back in acknowledgement.\n" +
                            "\n" +
                            "Alex: “Well, if it isn’t my new BFF. Isn’t it such a crazy coincidence that we ran into each other? I mean, unless you actually believe we have a mental bond now.”\n" +
                            "\n" +
                            "Your roommate laughs violently at their joke before speaking again.\n" +
                            "\n" +
                            "Alex: “Since you’re here, let’s hang out, you know, like real friends do. I feel I should warn you though, I spend a lot of time here with my other friend, so I’m pretty good at every game here.”\n" +
                            "\n" +
                            "You spend the rest of the day playing pool and ping pong with Alex. Actually, correction, you spend the rest of the day getting beat at pool and ping pong by Alex.\n\nPress any button to continue...");
                    san += 10;
                    sanity.setText(san + "/100");
                    s_bar.setValue(san);
                    gameState++;
                }
                else {
                    pane.setText("With nothing else to do, you decide to check out the recreational room in your dorm. Once there, you are taken aback by everything they had to offer. There were TVs on every wall for video games, pool tables, ping pong tables, and board games. Then, while you were scoping out the place, you notice someone waving excitedly in your direction. Focusing your gaze, you see someone that kind of looks like your roommate. Now, since the last time you actually got a good look at your roommate was in the summer, you are ultimately unsure if that person is truly them. Wanting to avoid any embarrassment, you proceed to act like you never saw the person waving. You then spend the rest of the day playing solo pool and ping pong table.\n\nPress any button to continue...");
                    san += 2;
                    sanity.setText(san + "/100");
                    s_bar.setValue(san);
                    gameState++;
                }
            }
        }
        else if (gameState== 17){
            if(e.getSource() == ch_1 || e.getSource() == ch_2) {
                pane.setText("After getting some dinner, you head back to the dorm to officially bring this day to a close. Upon entering your room, you see that the lights are off and your roommate appears to already be asleep. You sneak inside and think on what to do now.\n" +
                        "\n" +
                        "IV: “Today was rather uneventful and I mean that in a bad way. I guess the rec room was cool, but what kind of figment of your imagination would I be if I didn’t dream for more.”\n" +
                        "\n" +
                        "IV: “Well, tomorrow is another day as they say, but before that, we still have some time. Is there anything you want to do?”\n" +
                        "\n" +
                        "Study (Choice 1)\n" +
                        "Play on phone (Choice 2)\n");
                gameState=19;
            }
        }
        else if(gameState==18){
            if(e.getSource() == ch_1)
            {
                pane.setText("You studied! After studying, you go to bed.\n\nClick any button to continue...");
                san -= 2;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                preparedness += 5;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                gameState++;
            }
            if(e.getSource() == ch_2)
            {
                pane.setText("You had a great time playing on your phone. After that, you go to sleep.\n\nClick any button to continue...");
                san += 5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                gameState++;
            }
        }
        else if(gameState== 19){ //Day 3
            if(e.getSource() == ch_1 || e.getSource() == ch_2) {
                pane.setText("Day 3: Tuesday" +
                        "\n" +
                        "\n" +
                        "You wake up far easier this morning than you did yesterday. Partly because without morning classes, you were able to get an extra hour of sleep. It is currently 8:30 a.m. You sit up and engage in a rejuvenating stretch to get ready for the day.\n" +
                        "\n" +
                        "IV: “Wakey wakey eggs and whatever the hell else they serve for breakfast here.”\n" +
                        "\n" +
                        "IV: “It’s good to see that the events from yesterday didn’t get you too down. Today is a new day and since you don’t have class until the afternoon, we have the morning to do whatever we want. However, I feel inclined to inform you that today is the day of that club thing that weird girl was going on about two days ago. So, we can go check that out or, god help me if you say study.”\n\n" +
                        "Go to Open House (Choice 1)\n" +
                        "Study until class starts (Choice 2)\n");
                gameState++;
            }
        }
        else if(gameState==20){
            if(e.getSource() == ch_1){
                pane.setText("Upon your first time entering the Memorial Student Center, you are surprised by the sheer size of the building. This is a trait you quickly come to appreciate as you also notice the overwhelming volume of people shuffling through the building. Like a river, groups of people with barely a foot in between each other walking in a stream down the halls. The walls were lined with booths as well. Occasionally, people would stop at the booths to inquire about their respective clubs. After you grow accustomed to the seemingly controlled chaos, you slowly join the stream.\n" +
                        "\n" +
                        "After about 5 minutes of walking at a snail's pace and getting intimately related to every shoulder in a 1 meter radius, you somehow ended up on the second floor. You had stopped at a few booths here and there, but nothing really seemed interesting to you. Right as you are about to leave, you hear a familiar voice.\n" +
                        "\n" +
                        "Unknown Woman: “It’s good to see that you haven’t changed much. Still as lost as the last time I saw you. How have you been Headlights?”\n" +
                        "\n" +
                        "You turn around in confusion. After a few moments of looking around, you can see the girl standing behind a booth. Upon closer inspection, you notice that a sign on the booth clearly reads “People Watching Club”.\n" +
                        "\n" +
                        "Unknown Woman: “You see. It’s that continuous look of bewilderment is the reason I call you Headlights. You act like you’re always waiting for someone to tell what to do. Although, I’ll admit. Our club’s name often requires a double-take. Anyway, since you’re here, let me start the pitch.”\n" +
                        "\n" +
                        "Harper: “Howdy! My name is Harper Taylor and I am the founder and president of the People Watching Club where diversity is our mantra. To put it frankly, people are strange creatures and we just want to observe and record them like scientists do with every other animal in the wild. In fact, that’s exactly what I was doing when I saw you the other day. I even put together a wicked paper about you that I plan to share with all the new members.”\n" +
                        "\n" +
                        "Harper: “So, what do you say, would you like to join? In my experience, this org is a great way to meet people. Now, they’ll be a little strange, but you aren’t so normal yourself.”\n" +
                        "\n" +
                        "Accept the offer (Choice 1)\n" +
                        "Decline the offer (Choice 2)\n");
                san+=5;
                sanity.setText(san + "/100");
                s_bar.setValue(san);
                gameState++;
            }
            if(e.getSource() == ch_2){
                pane.setText("After studying for several hours, you make your way to class, but, since you are early, you sit down at a bench right outside the building. The time is 12:36 p.m.\n" +
                        "\n" +
                        "IV: “Let me get this straight. So, you study for 3 hours and then you go to class?”\n" +
                        "\n" +
                        "IV: “Look, all I’m saying is that this is not exactly the exciting college experience you see all the time in the movies. Let’s go have some fun. Besides, if you study too hard without taking some time for yourself, you’ll just burn out and that won’t be good for anybody.”\n" +
                        "\n" +
                        "\n" +
                        "Go to class (Choice 1)\n" +
                        "Play hooky (Choice 2)\n");
                preparedness += 10;
                prep.setText(preparedness+"/100");
                p_bar.setValue(preparedness);
                gameState=22;
            }
        }
        else if(gameState== 21){
            if(e.getSource()==ch_1){
                pane.setText("It took you a moment to respond. You were still in shock from the ridiculous purpose of this club, but at the same time, it seemed intriguing. In fact, the more you thought about it, the more you began to realize how fun this club may be.You then inform Harper that you would love to join her organization.\n" +
                        "\n" +
                        "Harper: “Glad to hear it. Our first meeting is two days from now at 6:30 p.m. The meeting will be held in room 215 at the MSC. Certainly, even a Freshman can find the MSC. Also, I am also expecting all potential members to prove their interest by bringing a report over someone they recently observed before the start of the meeting. Don’t worry. It doesn’t have to be anything too wordy or professional. In fact, we tend to discourage that type of behavior here. Just try and make it interesting. As a tip, just remember that the best part of people watching is to make your own assumptions. No one really knows the truth, so you’re allowed to stretch it a little.”\n" +
                        "\n" +
                        "Harper: “Anyway, I hate to shoo you away, but there are way more people here than you and, like I said, our numbers have been sort of lacking. I’ll see you later Headlights.\n\nAfter struggling the fight your way through the sea of people, you finally make your way back outside to the front of the MSC. The time is 12:43 p.m.\n" +
                        "\n" +
                        "IV: “Wow. You really know how to draw in the weird ones and when people were telling you to get involved, I don’t think a creeper club is what they had in mind. But, hey, at least it doesn’t sound boring.”\n" +
                        "\n" +
                        "IV: “Anyway, that little tour took all of our free time, so now you have to get to class. Unless, of course, you want to do something else; something a little more fun perhaps?”\n" +
                        "\n" +
                        "Go to class (Choice 1)\n" +
                        "Play hooky (Choice 2)\n");
                san+=5;
                sanity.setText(san+"/100");
                s_bar.setValue(san);
                gameState++;
            }
            if(e.getSource() == ch_2) {
                pane.setText("It took you a moment to respond. You were still in shock from the ridiculous purpose of this club. You then begin to wonder who would even join an organization like this. You give it a few more moments of thought, but you eventually come to the decision that you are far too busy with school to even consider joining a club of any kind. With that in mind, you politely refuse the offer.\n" +
                        "\n" +
                        "Harper: “Oh. I’m sorry to hear that, but I’m not too surprised either. You won’t believe how many people are put off by what we do. Trust me when I say we know it’s weird, but that’s why we love it. Anyway, I wish I could change your mind, but there are still a lot of other people here I need to try and convince. Have a good day and maybe I’ll see you around campus, but not in a strange way. Also, don’t worry. I was just kidding about the report.”\n\nAfter struggling the fight your way through the sea of people, you finally make your way back outside to the front of the MSC. The time is 12:43 p.m.\n" +
                        "\n" +
                        "IV: “Wow. You really know how to draw in the weird ones and when people were telling you to get involved, I don’t think a creeper club is what they had in mind. I know that girl seemed disappointed, but if you ask me, I think you made the right choice not joining that club. That being said however, I hope you didn’t miss out on any cool events.”\n" +
                        "\n" +
                        "IV: “Anyway, that little tour took all of our free time, so now you have to get to class. Unless, of course, you want to do something else; something a little more fun perhaps?”\n" +
                        "\n" +
                        "Go to class (Choice 1)\n" +
                        "Play hooky (Choice 2)\n");
                gameState++;
            }
        }
        else if(gameState==22){
            if (e.getSource()==ch_1){
                pane.setText("You enter the Science building and make your way to the lecture hall. This room was massive with rows upon rows of chairs. However, who designed this place didn’t take comfort or convenience into consideration. The fold up chairs were so tightly packed together that getting to a seat didn’t come without smacking knees. Even better, once you finally sit down, your neighbors have the pleasure of feeling every move you make. Despite this, you still pull out your notebook and prepare to take notes for when class finally starts.\n" +
                        "\n" +
                        "IV: “Call it intuition or, in my case, ESP, but I knew this place was gonna suck. If you weren’t such a boring goody two shoes, we wouldn’t have to suffer and… Hey! Don’t ignore me!”\n" +
                        "\n" +
                        "You quickly turn your attention to the front of the classroom as you notice a woman in business attire hastily approach the board and begin writing. It didn’t take long to realize that she was writing her name.\n" +
                        "\n" +
                        "Professor: “Good afternoon class. My name is Jessica Shade, but you will refer to me as Dr. Shade. You’ve probably heard this already, but we didn’t spend an eternity in graduate school to just get called Professor So and So. Welcome to CHEM 107.”\n" +
                        "\n" +
                        "Prof. Shade: “Now, I don’t mean to alarm anyone, but this is going to be a difficult class. There will be a lot of homework, weekly quizzes, and only those that study will have a chance at passing my exams. Because of this fact, I decided to go easy on you for the first week. We are just going to go over the syllabus today and start lecturing next time. So, without further ado, let’s begin.”\n" +
                        "\n" +
                        "She then proceeds to write about office hours, exam dates, and other general information. All things which you could have just looked up on her class homepage. As she continues, you slouch in your chair and begin to grow lost in your thoughts.”\n" +
                        "\n" +
                        "IV: “So...I would hate to say I told you so. Oh, who am I kidding? We both know that’s not true. I TOLD YOU SO!!! I knew this class wasn’t going to be important. Now, while I sit here and revel in my being right, you can just sit there and not learn.” \n" +
                        "\n" +
                        "Once class finally ends, you rush out of the classroom to stretch your legs and to decide what to do next. The time is 2:22 p.m.\n" +
                        "\n" +
                        "Study (Choice 1)\n" +
                        "Go to a movie (Choice 2)\n");
                gameState++;
            }
            if(e.getSource() == ch_2){
                pane.setText("Still full of energy, you decide to head to the A&M Rec Center to get a workout. Only stopping by your dorm to change clothes and grab a towel. You begin your workout as soon as you enter the weight room. Since you don’t get to workout often, you decide to do a full body circuit. You do bench press, squats, crunches and everything in between. Then, after an hour, you head to the track on the top floor to run a mile. After you finish, you fall to the ground off the track. You lay there for several minutes waiting for your lungs to stop trying to kill you.\n" +
                        "\n" +
                        "IV: “Dang! You really pushed yourself today. That all looked super exhausting too. Well, I am glad to announce that you didn’t do all of that for nothing.”\n" +
                        "\n" +
                        "IV: “Congratulations, you have earned +1 Strength and +1 Stamina!!!”\n" +
                        "\n" +
                        "IV: “What did you say?”\n" +
                        "\n" +
                        "IV: “No, of course there aren’t any meters for Strength or Stamina. What kind of high fantasy RPG do you think this is? I just wanted to let you know you did all of that for nothing.”\n" +
                        "\n" +
                        "IV: “Intelligence? Okay, so that one actually was considered, but the creators didn’t want you to get upset when you saw it was empty.”\n" +
                        "\n" +
                        "Sore and upset, you grab your stuff and out of your locker and head home.\n\n" +
                        "You are greeted, once again, by a sleeping roommate when you open the door. You get changed and consider your options.\n" +
                        "\n" +
                        "IV: “Alright! How about we actually do something useful before we have to just mark this whole day down as a complete waste of time and energy.”\n" +
                        "\n" +
                        "Study (Choice 1)\n" +
                        "Read a book (Choice 2)\n");
                san+=2;
                sanity.setText(san+"/100");
                s_bar.setValue(san);
                gameState=24;
            }
        }
        else if(gameState==23){
            if(e.getSource() == ch_1){
                pane.setText("You spend the majority of the rest of day studying. You go to bed early\n\nPress any button to continue...");
                san+=2;
                preparedness+=5;
                s_bar.setValue(san);
                p_bar.setValue(preparedness);
                prep.setText(preparedness+"/100");
                sanity.setText(san + "/100");
                gameState=25;
            }
            if(e.getSource() == ch_2){
                pane.setText("Instead of going to class, you decide to go check out a movie. Once at the theatre, you buy your ticket, popcorn, and a drink. You make your way to your seat and begin munching on your popcorn. Being a spur of the moment decision, the only thing you know about the movie is that it’s some sort of comedy directed by and starring some actor named Adam Santler. After 15 minutes and about half your popcorn the movie begins.\n" +
                        "\n" +
                        "45 minutes later\n" +
                        "\n" +
                        "IV: “Wow! I had no idea 7 year olds were allowed to write movie scripts. And the acting; they did a great job at being relatable. I mean, it really feels like they just pulled these people off the street. Don’t even get me started on the directing. Pretty impressive stuff for what I can only assume was a chimp on LSD.”\n" +
                        "\n" +
                        "IV: “All I’m saying is that it is a REALLY good thing you can’t get dumber by watching these dumpster fires.”\n" +
                        "\n" +
                        "You decide to head back to your dorm.\n" +
                        "\n" +
                        "You are greeted, once again, by a sleeping roommate when you open the door. You get changed and consider your options.\n" +
                        "\n" +
                        "IV: “Alright! How about we actually do something useful before we have to just mark this whole day down as a complete waste of time and energy.”\n" +
                        "\n" +
                        "Study (Choice 1)\n" +
                        "Read a book (Choice 2)\n");
                preparedness-=3;
                prep.setText(preparedness+"/100");
                p_bar.setValue(preparedness);
                gameState++;
            }
        }
        else if(gameState==24) {
            if (e.getSource() == ch_1) {
                pane.setText("You spend the rest of day studying. You go to bed early.\n\nPress any button to continue...");
                san += 2;
                preparedness += 5;
                s_bar.setValue(san);
                p_bar.setValue(preparedness);
                prep.setText(preparedness + "/100");
                sanity.setText(san + "/100");
                gameState++;
            }
            if (e.getSource() == ch_2) {
                pane.setText("You read a really nice book and then go to sleep.\n\nPress any button to continue...");
                san += 3;
                preparedness += 1;
                s_bar.setValue(san);
                p_bar.setValue(preparedness);
                prep.setText(preparedness + "/100");
                sanity.setText(san + "/100");
                gameState++;
            }
        }
        else if(gameState==25) {//Day 4
            if(e.getSource()==ch_1 || e.getSource()==ch_2){
                pane.setText("Day 4: Wednesday" +
                        "\n" +
                        "\n" +
                        "You are awoken violently to the loud beeping of your phone alarm. It is 7:30 in the morning and it is time to get ready for class. Getting more accustomed to the routine, you jump out of bed and head to the bathroom to get ready for the day.\n" +
                        "\n" +
                        "IV: “Not to be a Debbie Downer, but has anything really happened to warrant this pep in your step? I just don’t get why you are in such a rush to get to an 8:00 a.m. class. Isn’t that supposed to be the bane of every college student?”\n" +
                        "\n" +
                        "You quickly pull yourself away from these thoughts as you prepare to head out for class. You are determined to be a productive student today. Then you hear the distinct sound of your phone’s message ringtone.\n" +
                        "\n" +
                        "IV: “Who on Earth sends a message this early in the morning? I don’t remember exchanging numbers with a lunatic.”\n" +
                        "\n" +
                        "After returning to your bed, you check the name of the culprit on your phone. You clearly see the name Nathan Chen on the screen. You then immediately remember that he was one of the first people you met during your Fish Camp last summer. In fact, he was a member of your group. You also remember him being pretty funny and a generally cool person to hang out with. However, you still wonder why is texting you so early in the morning. To answer your question, you open your phone and read the text message without any more delay.\n" +
                        "\n" +
                        "Nathan: Hey, loser!!! Haven’t had the chance to check out the town, so a lot of us from camp are meeting up at 8:30 to hang out. Meet us at Lot 100 by Reed Arena if you want to come. Also, Connie will be there too, to drive.\n" +
                        "\n" +
                        "IV: “This is why I love random events! Those guys were so much fun at camp. You’re gonna go right? You have to go! This is where lasting friendships are made and you don’t want to be branded as some kind of square, right?\n" +
                        "\n" +
                        "Go to class (Choice 1)\n" +
                        "Go hang out (Choice 2)\n");
                gameState++;
            }
        }
        else if(gameState==26){
            if(e.getSource()==ch_1) {
                pane.setText("As you walk out the door of the dormitorium, you notice the menacing grey clouds overhead. Maybe it’s a good thing you decided not to go hang out with Nathan and Connie. It looks like it could downpour at any moment. As you make your way to Calculus, you had to check your phone as you were still a little unsure of its location. Once in the building, you take your seat and wait until your professor to start class.\n" +
                        "\n" +
                        "Dr. Oblonsky: “It’s so good to see all of your...well not smiling faces. I am also noticing a few new faces that I didn’t see on Monday. Maybe, some of you heard about my special quiz from the Monday class and decided it would be in your best interest to come to class.”\n" +
                        "\n" +
                        "Dr. Oblonsky: “Now, for those of you who have no idea what I am talking about. Pay close attention because this is the last time I will discuss it before the fact.”\n" +
                        "\n" +
                        "Dr. Oblonsky: “On Friday Morning, I will be administering a quiz which covers all of the material from lecture today, as well as Chapters 1 and 2 from the book. This quiz will be worth 10 percent of your final grade. So, from this point forward, I hope you continue to come to class and put in an adequate amount of time outside of lecture to prepare.”\n" +
                        "\n" +
                        "Dr. Oblonsky: “With that being said, I would think that many of you would prefer if I started the lecture now.”\n" +
                        "\n" +
                        "After that, the professor proceeded to lecture nonstop over the fundamentals of Calculus, only taking momentary breaks to answer questions.\n" +
                        "\n" +
                        "After 50 dreadful minutes of concepts which you could barely understand, you make your way outside the building. The first thing you notice is the torrential downpour. Streams were already starting to form down the paths. What do you do now?\n" +
                        "\n" +
                        "Study(Choice 1)\n" +
                        "Relax(Choice 2)\n");
                preparedness += 5;
                prep.setText(preparedness + "/100");
                p_bar.setValue(preparedness);
                gameState++;
            }
            if(e.getSource()==ch_2){
                pane.setText("Since you decided to skip class, you didn’t have to particularly rush in order to get to Lot 100. However, with the current state of the weather, you hope they show up soon. Dark, menacing clouds are covering the sky. Not a ray of sunlight can shine through. You can also hear the subtle roar of thunder.\n" +
                        "\n" +
                        "The time is now 9:13 a.m.\n" +
                        "\n" +
                        "IV: “9 in the morning my foot! Why did we ever think that guy was cool? Could have at least texted that they were going to be late.”\n" +
                        "\n" +
                        "IV: “Wait! You don’t think they forgot about us, do you? I mean, I know you’re not the most interesting person but that’s not my fault. Why couldn’t you get some kind of Charisma meter too?”\n" +
                        "\n" +
                        "Before your thoughts begin to grow too out of hand, you feel your phone vibrate. Hoping for answers, you rapidly pull your phone out and confirm that you do, indeed, have a text message from Nathan.\n" +
                        "\n" +
                        "Nathan: So, you’re probably gonna hate me for this, but Connie said she really needed to go to class this morning. Something about some big Calculus quiz. Maybe we can get together this weekend. Sorry.\n" +
                        "\n" +
                        "You slowly put your phone back into your pocket. A few seconds later, it begins to rain.\n" +
                        "\n" +
                        "IV: “He’s right. I do hate him.”\n" +
                        "\n" +
                        "You sprint back to your dorm so you can shower and get into dry clothes. With classes over for the day, what shall you do now?\n" +
                        "\n" +
                        "Study(Choice 1)\n" +
                        "Relax (Choice 2)\n");
                san-=3;
                sanity.setText(san+"/100");
                s_bar.setValue(san);
                gameState++;
            }
        }
        else if(gameState==27){
            if(e.getSource()==ch_1){
                pane.setText("Despite the rain, you decide to switch things up. You want to, instead, study at Evans library.\n" +
                        "\n" +
                        "The time is currently 4:28 p.m. You have been studying for about 3 hours. Then a peculiar man takes a seat next to you at your table. He places some pamphlets down on the table. Without looking too creepy, you take a peek at the pamphlets and notice a ghost on the cover and the words ‘Texas A&M Ghost Hunting Club”.\n" +
                        "\n" +
                        "Strange Man: “Are you interested in joining?”\n" +
                        "\n" +
                        "The man was now speaking to you. You notice his dirty blonde hair with a slightly receding hairline. At this moment, he is currently wearing jeans, a black t-shirt, and a green combat jacket.\n" +
                        "\n" +
                        "Strange Man: “The name’s John Cripson and I am the Vice President of the Texas A&M Ghost Hunting Club. And, before you ask, it’s exactly what it sounds like. We are committed to researching and locating the supernatural.”\n" +
                        "\n" +
                        "John: “Now, I have to get somewhere and, unfortunately, you missed our first meeting. However, and lucky for you, we are conducting our first investigation tomorrow at the Animal Industries Building. We are going to lock the doors at 7:00 p.m. So, if you are interested in seeing what we do, be there before then.”\n" +
                        "\n" +
                        "John quickly grabs his stuff and exits the library. However, with it still raining cats and dogs outside, you decide to stay here until it stops.\n\n" +
                        "Press any button to continue...");
                preparedness+=4;
                prep.setText(preparedness+"/100");
                p_bar.setValue(preparedness);
                gameState++;
            }
            if(e.getSource()==ch_2){
                pane.setText("Despite the rain, you decide to switch things up. You want to, instead, relax at Evans library.\n" +
                        "\n" +
                        "The time is currently 4:28 p.m. You have been on your phone watching Netflix for about 3 hours. Then a peculiar man takes a seat next to you at your table. He places some pamphlets down on the table. Without looking too creepy, you take a peek at the pamphlets and notice a ghost on the cover and the words ‘Texas A&M Ghost Hunting Club”.\n" +
                        "\n" +
                        "Strange Man: “Are you interested in joining?”\n" +
                        "\n" +
                        "The man was now speaking to you. You notice his dirty blonde hair with a slightly receding hairline. At this moment, he is currently wearing jeans, a black t-shirt, and a green combat jacket.\n" +
                        "\n" +
                        "Strange Man: “The name’s John Cripson and I am the Vice President of the Texas A&M Ghost Hunting Club. And, before you ask, it’s exactly what it sounds like. We are committed to researching and locating the supernatural.”\n" +
                        "\n" +
                        "John: “Now, I have to get somewhere and, unfortunately, you missed our first meeting. However, and lucky for you, we are conducting our first investigation tomorrow at the Animal Industries Building. We are going to lock the doors at 7:00 p.m. So, if you are interested in seeing what we do, be there before then.”\n" +
                        "\n" +
                        "John quickly grabs his stuff and exits the library. However, with it still raining cats and dogs outside, you decide to stay here until it stops.\n\nPress any button to continue...");
                san+=3;
                sanity.setText(san+"/100");
                s_bar.setValue(san);
                gameState++;
            }
        }
        else if(gameState==28){
            if(e.getSource()==ch_1 | e.getSource()==ch_2) {
                if (resisted && !copsCalled) { //Page 7
                    pane.setText("It finally stopped raining. The time is 9:52 p.m. Having sufficiently studied for the day, you pack up your things and head out of the library. Something seems different about this night. It was extremely quiet, especially for a college campus. You are almost to your dorm, but you have to cross through a dark lot first. You’re unsettled by the idea, but you shake off the fear and continue on.\n" +
                            "\n" +
                            "You’re about halfway across the lot, but, suddenly, someone grabs your arm from behind, spins you, and shoves you into the building wall near you. A hand covers your mouth before you get the chance to scream.\n" +
                            "\n" +
                            "Before you, is a tall man. He was wearing a black hoodie and the hood was up. You couldn’t really see the face, but you notice the brown, messy beard. The bearded man pulls out the familiar knife and, once again, presses it to your throat.\n" +
                            "\n" +
                            "Bearded Man: “Did you just think you could hurt me like you did and just get away with it? I bet you felt pretty tough. I bet you also didn’t realize that I got a pretty good look at your ID before your grand escape. Finding you was a breeze.”\n" +
                            "\n" +
                            "Bearded Man: “All you had to do was give me your money and you could go back to your stupid little college life. Well, you made a poor decision, and now you have to pay for it.”\n\n" +
                            "You were killed\n" +
                            "Game Over\n\nThank you for playing!\n\nPlay Again(choice 1)\nQuit(choice 2)");
                    gameState++;
                    san=0;
                    sanity.setText("You Died");
                    s_bar.setValue(san);
                    preparedness=0;
                    prep.setText("You Died");
                    p_bar.setValue(preparedness);
                } else if (resisted && copsCalled) { //Page 9
                    pane.setText("The rain finally stopped. The time is 9:52 p.m. You pack up your things and head out of the library. However, before you are able to walk down the library steps, your phone begins to ring.\n" +
                            "Pulling out your phone, you notice it’s the number of one of the detectives from Monday. You quickly answer and are greeted by the deep voice of the detective.\n" +
                            "\n" +
                            "Detective: “Yes. Hello. I wanted to call and inform you that we have arrested the man who tried to rob you the other night.”\n" +
                            "\n" +
                            "Detective: “His name is Charles Wickman and apparently you weren’t the only person he assaulted. We were able to link him to the murder of another college student. A girl named Bethanie Thomas.”\n" +
                            "\n" +
                            "Detective: “I also wanted to call and thank you. Apparently, you must have really dug your foot into him because our officers said he was clutching his gut while he tried to escape. Made catching him pretty easy when he could barely run.”\n" +
                            "\n" +
                            "Shocked but overjoyed by the news you thank the detective for his work.\n" +
                            "\n" +
                            "Detective: “Just doing my job. You have a safe night.”\n" +
                            "\n" +
                            "The detective hangs up and you head back to your dorm. As always, your roommate is already asleep so you put on your pajamas and go to sleep.\n\nPress any button to continue...");
                    san+=5;
                    sanity.setText(san+"/100");
                    s_bar.setValue(san);
                    gameState+=2;
                } else if (robbed && copsCalled) { //Page 8
                    pane.setText("It finally stopped raining. The time is 9:52 p.m. Having sufficiently studied for the day, you pack up your things and head out of the library. Something seems different about this night. It was extremely quiet, especially for a college campus. You are almost to your dorm, but you have to cross through a dark lot first. You’re unsettled by the idea, but you shake off the fear and continue on.\n" +
                            "\n" +
                            "You’re about halfway across the lot, but, suddenly, someone grabs your arm from behind, spins you, and shoves you into the building wall near you. A hand covers your mouth before you get the chance to scream.\n" +
                            "\n" +
                            "Before you, is a tall man. He was wearing a black hoodie and the hood was up. You couldn’t really see the face, but you notice the brown, messy beard. The bearded man pulls out the familiar knife and, once again, presses it to your through.\n" +
                            "\n" +
                            "Bearded Man: “How did you make it to college? I only ask because it seems you have a seriously listening problem. But, just to be sure, let’s have a quick quiz. What did you do wrong?”\n" +
                            "\n" +
                            "The question was firm, but, of course, you are unable to answer because of the hand firmly clamped over your mouth.\n" +
                            "\n" +
                            "Bearded Man: “That’s what I thought. Well, let me make it simple, I told you very clearly not to call the cops, but you did and I wasn’t very happy when I saw a rough sketch of me on the morning news. And, unlike you, I’m not stupid. I quickly guessed that you neglected my advice and then all I had to do was find you, which wasn’t very hard since I got a pretty good look at your ID before I took your money. I like to be prepared.”\n" +
                            "\n" +
                            "Bearded Man: “Anyway, since you didn’t listen the first time. I have to make sure this next lesson really sticks.”\n" +
                            "\n" +
                            "You were killed\n" +
                            "Game Over\n\nThank you for playing!\n\nPlay Again(choice 1)\nQuit(choice 2)");
                    gameState++;
                } else { //Page 6
                    pane.setText("The rain finally stopped. The time is 9:52 p.m. You pack up your things and head out of the library. After a wet but quiet walk, you find yourself back in your dorm. As always, your roommate is already asleep so you put on your pajamas and lay down to bed. However, you become lost in your thoughts before you get the chance to fall asleep.\n" +
                            "\n" +
                            "IV: “I’m just gonna go ahead and say it. Today sucked. We didn’t do anything fun and nothing exciting happened. I hope you’re happy with yourself.”\n" +
                            "\n" +
                            "IV: “Maybe you should consider making better choices next time because this is a snooze fest. Despite all of my best efforts, it seems like you are determined to make your college experience a boring experience.”\n" +
                            "\n" +
                            "IV: “I just feel like if you had done something different, we would not just be laying in bed right now. Actually, you know what, I’m so angry right now that I don’t even want to talk to you anymore. Goodnight ya drag.”\n" +
                            "\n" +
                            "After that, you pull your covers over your head and drift off to sleep.\n\n" +
                            "Press any button to continue...");
                    gameState+=2;
                }
            }
        }
        else if(gameState==29){
            if(e.getSource()==ch_1) {
                CS445_GUI_MN t = null;
                try {
                    t = new CS445_GUI_MN();
                    t.setVisible(true);
                    this.dispose();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
            if(e.getSource()==ch_2){
                System.exit(0);
            }
        }
        else if(gameState==30) { //Day 5
            if(e.getSource()==ch_1||e.getSource()==ch_2){
                pane.setText("Day 5: Thursday" + "\n\n" + "" +
                        "You wake up at 8:30 in the morning. There was no alarm, you just eased into wakefulness and\n" +
                        "you are completely relaxed because of it. You slip out of bed and begin your morning stretches\n" +
                        "to get your muscles ready for the day. After this, you shower, brush your teeth, and get dressed.\n" +
                        "You’re ready to get rolling.\n" +
                        "IV: Good to see that you’re alive. Could have mistaken you for a corpse with how heavy you\n" +
                        "IV: were sleeping. Well, forget that. Like Tuesday, you have a lot of free time until class starts.\n" +
                        "IV: You also have the choice of two different events tonight. There’s the meeting for the Stalker\n" +
                        "IV: Association and then there’s the investigation with Scooby and the gang. However, their times\n" +
                        "IV: conflict considerably, so you are only going to be able to make it to one event.\n" +
                        "IV: I think it would be best to decide now which event you are planning to attend because the\n" +
                        "IV: People Watching Club requires a paper before the meeting. So, what will it be partner?\n" +
                        "The People Watching Club (Choice 1)\n" +
                        "The Ghost Hunting Club (Choice 2)\n");
                gameState++;
            }
        }
        else if(gameState == 31) {
            if(e.getSource() == ch_1) {
                pane.setText("Upon deciding to attend the People Watching Club meeting this evening, you finish getting\n" +
                        "ready, grab a notebook and pencil, and head out the door. You plan to hit up the nearest park so\n" +
                        "you can get various candidates, prime for examination.\n" +
                        "Upon reaching the park, you take a seat at a wooden bench which gives you a broad view of \n" +
                        "your surroundings. For example, you can see an amphitheatre, an outdoor dining area, and a \n" +
                        "playground. The time is currently 9:03 a.m. and you begin to survey the area. There are many \n" +
                        "people in the park this morning, but, so far, there is nobody worth writing about. That is until \n" +
                        "9:28 when you notice two abnormal individuals.\n" +
                        "The first one is a man just staring ominously at a statue of a wolf. He also has, what some \n" +
                        "would consider, a crazy look in his eye.\n" +
                        "The second weird person is what appears to be a young adult wearing a black hoodie and \n" +
                        "carrying a sack. This is definitely odd as no sane person would be wearing anything like that in \n" +
                        "Texas at this time of year. \n" +
                        "How do you want to follow?\n\n" +
                        "The Strange Man (Choice 1)\n" +
                        "The Hooded Figure (Choice 2)\n");
                gameState++;
            }
            if(e.getSource() == ch_2) {
                pane.setText("IV: So, you decided to join Ghost Adventures this evening. I’ll admit. Between the two very \n" +
                        "IV: unusual choices, that one definitely seemed more exciting. I hope Harper doesn’t take it too hard.\n" +
                        "IV: Oh well. No point in getting too worked up over it. Your decision is made and you have to \n" +
                        "IV: stick with it. You don’t want to be one of those wishy washy people that overthink everything and \n" +
                        "IV: worry too much about the what if. If you lived like that, you would never make any progress.\n" +
                        "IV: Anyway, since you don’t have to write that paper anymore, how about we do something else \n" +
                        "IV: while we wait for classes to start, but nothing too crazy please.\n" +
                        "Study (Choice 1)\n" +
                        "Watch Some Movies (Choice 2)\n");
                gameState = 36;
            }
        }
        else if(gameState == 32) {
            if(e.getSource() == ch_1) {
                pane.setText("Carefully, you move closer to the man by the statue in an attempt to not be noticed. You can \n" +
                        "now make out more defining details. For one thing, he was far older than you. He is at least 50. \n" +
                        "His skin was rough and wrinkled. His hair was long, grey and thinning. The clothes he wore \n " +
                        "were about as beat up as he was. The man was wearing a worn out flannel shirt with a thick \n" +
                        "brown coat. He was also wearing jeans, but no shoes. Every article of clothing was riddled with tears and holes.\n" +
                        "After a few more minutes of staring at the statue, the man proceeds to lick it and walk out of the \n" +
                        "park. Curious, you follow the man. Making sure to stay far enough behind as not to catch his \n" +
                        "attention, the man walks for about 10 minutes until he is behind a Chinese restaurant. Once \n" +
                        "here, he climbs into the restaurant’s dumpster and begins rustling around. You very quickly \n" +
                        "surmise that you are dealing with a local hobo. You consider leaving, but quickly decide against \n" +
                        "as this would be your best chance at putting together a somewhat interesting paper and you’re \n" +
                        "not sure if you would even find anyone else before you had to get to class.\n" +
                        "Once you finally make your decision to stay, the man climbs out of the dumpster carrying an \n" +
                        "armful of what you assume to be expired chicken and beef. He once again starts walking and \n" +
                        "you follow him. It wasn’t as long of a walk this time, only about 3 or 5 minutes. You watch the \n" +
                        "man shuffle into an alley. Peeking into the alley, you now understand why the man took so much food which couldn’t last.\n" +
                        "As soon as the man entered the shadow covered alley, three dogs came out of their respective \n" +
                        "hiding spots. Two of the mutts were a bright brown color. The other dog was much older than \n" +
                        "the rest and was missing its front left leg. All of them were very malnourished. The hobo then \n" +
                        "began to distribute the food equally among the dogs. Well, almost equally. He gave a larger \n" +
                        "piece of beef to the oldest dog.\n" +
                        "Then one of the younger mutts suddenly perks up and looks in your directions. The man notices \n" +
                        "this and immediately makes eye contact with you. In that moment, you realize that the hobo’s \n" +
                        "eyes were milky. You weren’t sure how blind he was, but you were sure his vision was impared. \n" +
                        "You step forward to explain yourself, but before you can even say a word the man drops down to his hands.\n" +
                        "The man’s look shifts from one of surprise, to a look of anger. He snarls and also begins to \n" +
                        "growl. He inches closer, so you begin to back away. The hobo then begins to bark and this \n" +
                        "causes the other dogs to begin barking as they are now all moving closer towards you. \n" +
                        "However, before you give them a chance to strike, you sprint in the opposite direction. After \n" +
                        "making it back to the park, you can still hear the distinct howls and barks of the dogs, but you know that you got away.\n\nPress any button to continue...");
                gameState = 38;
            }
            if(e.getSource() == ch_2) {
                pane.setText("Very carefully, you follow the hooded figure as they continue down the park trail. You are unable \n" +
                        "to see any distinct characteristics of the individual. The person continued walking for roughly 15 \n" +
                        "minutes. There were times you even considered heading back, but you were far too curious. \n" +
                        "Every now and then, the hooded figure would quickly look around, searching for any pursuers. \n" +
                        "Luckily, you made sure to stay close to the nearby trees so you could hide whenever necessary. \n" +
                        "Suddenly, they stopped and took a sharp left. They were now leaving the park. You decide to \n" +
                        "hang a little further back, just to see where they go. This strange individual, however, did not \n" +
                        "travel much further as you notice them heading towards an abandoned warehouse just outside \n" +
                        "the park. They open a door at the back of the building and head inside.\n" +
                        "Follow Them (Choice 1)\n" +
                        "Give Up (Choice 2)\n");
                gameState++;
            }
        }
        else if(gameState == 33) {
            if(e.getSource() == ch_1) {
                pane.setText("Steeling your nerves, you decide to stick with what you started. After waiting about 5 minutes, \n" +
                        "you also go inside the building; through the same door as the hooded figure. Once inside, you \n" +
                        "very quickly find yourself a large stack of boxes to hide behind. Slowly, you peer around the \n" +
                        "boxes to survey your surroundings.\n" +
                        "It appears the warehouse has been abandoned for quite some time. Boxes were the only items \n" +
                        "left in the building. Well, that’s if you exclude all of the cobwebs and rat droppings. The building \n" +
                        "consisted of rows of pillars and upon closer inspection, you find the hooded figure. They were in \n" +
                        "the middle of the building. In fact, it’s a miracle that they didn’t see you as you came in. The \n" +
                        "ominous individual was standing next to one of the columns, but something was different about \n" +
                        "this one. Chained tightly to the pillar was a girl. A dead girl.\n" +
                        "Hooded Figure: NO NO NO NO!!!\n" +
                        "Hooded Figure: Why would you do this to me? Was I not a good friend? Did I not visit you \n" +
                        "Hooded Figure: every day and feed you well? So, why would you just leave me?\n" +
                        "You are terrified. You were so scared that you didn’t even notice that your breath had grown \n" +
                        "heavier and louder. They hear.\n" +
                        "Hooded Figure: Is someone there? If there is anyone there, please. I just want to talk.\n" +
                        "You try to stand up to try and bolt for the door, but your foot bumps into the boxes and they all \n" +
                        "tumble on top of you. The force of the boxes knocks you to the grounds. Once you recollect \n" +
                        "yourself, the psycho was already standing over you. They are also pointing what appears to be \n" +
                        "a gun at you, but it looked different from any gun you had ever seen before. More importantly, \n" +
                        "you are now able to see the face of your assailant. Under the dark hood, you see the face of your roommate.\n\nPress any button to continue...");
                gameState++;
            }
            if(e.getSource() == ch_2) {
                pane.setText("The time is 6:28 p.m. You went to classes, but, like last time, they did not provide any pertinent \n" +
                        "information. So, you mostly spent class time writing your paper over the strange, hooded figure \n" +
                        "you followed earlier today. Since you didn’t really follow them for long or see anything \n" +
                        "interesting, you decide to spice up the story a little. You enter the meeting room and are greeted \n" +
                        "by an overwhelming crowd of 11 people. Harper, currently standing at a podium at the front of \n" +
                        "the room, notices you, smiles and approaches to greet you.\n" +
                        "Harper: I’m actually surprised you came Headlights.\n" +
                        "You look at Harper with disbelief.\n" +
                        "Harper: Don’t give me that look. I had over 20 people tell me they would swing by and check us out, but, as you can see, that’s not exactly the case. Anyway, are you ready to give your report?\n" +
                        "Unaware that you would be giving the report orally, you frantically ask about the report she was going to give.\n" +
                        "Harper: Oh that? Yeah, that was just a little fib I told you to make sure you showed up. We do a \n" +
                        "Harper: lot of fibbing here. That being said, I did need someone to demonstrate what we do here. So...\n" +
                        "Once again, you ask why didn't she just do it.\n" +
                        "Harper: Seriously!? These pure, innocent people aren’t ready for my masterpieces, so I thought somebody with a little less experience should do it. So, up you go.\n" +
                        "Suddenly, Harper pushes you towards the podium and all eyes fall on you. Desperate to end the \n" +
                        "awkward silence, you go ahead and read your report about the hooded figure. You describe \n" +
                        "how you sneakily followed them to an abandoned warehouse. Then you explain how you \n" +
                        "followed them inside to discover that they had kidnapped someone and were holding them \n" +
                        "hostage inside the warehouse. Claiming that you had seen enough, you describe rushing out of \n" +
                        "the building before they could notice you.\n" +
                        "Once you finish, only 2 of the audience and Harper clap. Following this, Harper points you to a \n" +
                        "seat and begins the meeting. After about 30 minutes, the meeting ends and Harper comes toward you laughing.\n" +
                        "Harper: That was...interesting. Got a little crazy there at the end, didn’t it? I mean, I know I told \n" +
                        "Harper: you that you could stretch the truth a little, but that was a little much. I would say there’s always \n" +
                        "Harper: next time, but, unfortunately, only 3 people signed up for the club. We need at least 10 active \n" +
                        "Harper: members, so I guess there won’t be a next time.\n" +
                        "Harper: But, don’t stress about it. I was already pretty certain that this was gonna happen. I \n" +
                        "Harper: hope you at least had a good time and, hey, I’m sure I’ll still see you around campus.\n" +
                        "There was an uncomfortable moment of disappointing silence before Harper spoke again.\n" +
                        "Harper: Catch ya later Headlights.\n\nPress any button to continue...");
                gameState = 39;
            }
        }
        else if(gameState == 34) {
            if(friend == true) {
                pane.setText("Alex: I can’t tell you how happy I am to see you. As you can see, I’m not doing so well right\n" +
                        "Alex: now. Do you know what it’s like to trust someone, to LOVE someone, just for them to leave you?\n" +
                        "Alex: She was supposed to be my friend, but then she started complaining. She said I was too clingy \n" +
                        "Alex: and got emotional too often. I’m sorry that I’m attentive and care too much.\n" +
                        "Alex: Then she started ignoring and avoiding me, so I did the only thing I knew would make it \n" +
                        "Alex: better. And things were better. She was talking to me again and she became so caring. She \n" +
                        "Alex: kept talking about how worried she was. But, I guess I did something wrong. Why else would \n" +
                        "Alex: she bite her own tongue off?\n" +
                        "Alex: This time will be different though. Because, now, I have you and you already told me we \n" +
                        "Alex: were friends. Now, I know we don’t really know each other, but we can fix that...with enough time\n" +
                        "Without warning, Alex pulls the trigger of the stun gun and your body immediately seizes up. \n" +
                        "The pain is excruciating and movement becomes impossible.\n" +
                        "You were captured. Game Over\n" +
                        "Play Again (Choice 1)\n" +
                        "Quit (Choice 2)\n");
                gameState++;
            }
            if(!friend) {
                pane.setText("Roommate: What are you doing here? You don’t belong here. This is a sacred place and only my friends are allowed here.\n" +
                        "You try to plead with your roommate. You even claim that you are friends.\n" +
                        "Roommate: Real friends don’t avoid each other. Did you think I didn’t notice? Do you even know my name?\n" +
                        "Already crying, you continue to beg for your life as you are unable to answer the question.\n" +
                        "Roommate: I knew it. You’re just as bad as she was. Except, I didn’t want her to die.\n" +
                        "Without warning, Alex pulls the trigger of the stun gun and your body immediately seizes up. \n" +
                        "The pain is excruciating and movement becomes impossible.\n" +
                        "You were killed. Game Over\n" +
                        "Play Again (Choice 1)\n" +
                        "Quit (Choice 2)\n");
                gameState++;
            }
        }
        else if (gameState == 35)
        {
            if(e.getSource()==ch_1) {
                CS445_GUI_MN t = null;
                try {
                    t = new CS445_GUI_MN();
                    t.setVisible(true);
                    this.dispose();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
            if(e.getSource()==ch_2){
                System.exit(0);
            }
        }
        else if (gameState == 36) {
            if(e.getSource() == ch_1) {
                preparedness+=4;
                prep.setText(preparedness+"/100");
                p_bar.setValue(preparedness);
            }
            else if(e.getSource() == ch_2) {
                san+=3;
                sanity.setText(san+"/100");
                s_bar.setValue(san);
            }

            pane.setText("The time is 6:53 p.m. You went to classes, but, like last time, they did not provide any pertinent \n" +
                    "information. So, you mostly spent class time fantasizing about this investigation. You are \n" +
                    "currently standing in front of the Animal Industries building with a doubtful look present upon \n" +
                    "your face. Basically, you were almost certain that the only dead thing here were students’ hopes \n" +
                    "and dreams. Nevertheless, you enter through the glass doors and meet John Cripson inside.\n" +
                    "John: I’m surprised you actually came. I thought you might have been too scared for this kind \n" +
                    "John: of thing. Since you are here, I hope you’re ready to work.\n" +
                    "John walks over to a black duffel bag and pulls out two strange, and kind of cheap, looking devices.\n" +
                    "John: Most of our gear has already been claimed by other members, so this is all that’s left.\n" +
                    "John: But, do not underestimate them as they are vital to any effective investigation.\n" +
                    "First, John holds up the device in his left hand. It kind of looked like a TV remote, except there were 5 lights at the top-front of the gadget.\n" +
                    "John: This is an EMF Detector. You see, spirits give off an electromagnetic signal and this \n" +
                    "John: baby can pick it up. The number of lights that come on indicate the strength of the signal. Now, if \n" +
                    "John: you use this one, make sure you stay away from any large electrical devices as they will also give off EMF.\n" +
                    "Next, he displayed the device in his right hand. This one looks like a small handheld radio.\n" +
                    "John: This is one of my favorites. I give you the SB-7 Spirit Box. This baby cycles through \n" +
                    "John: radio static at high speeds. What for, you may be wondering. Well, it is believed that spirits are \n" +
                    "John: able to communicate through the white noise if you listen close enough. This device allows for \n" +
                    "John: open communication with a nearby spirit.\n" +
                    "John: “So, you need to take one of these devices and sweep the building for any activity. Now, \n" +
                    "John: don’t be shy. Which one do you want?\n" +
                    "EMF Detector (Choice 1)\n" +
                    "Spirit Box (Choice 2)\n");
            gameState++;
        }
        else if(gameState == 37) {
            if(e.getSource() == ch_1) {
                pane.setText("With the EMF detector in hand, you proceed to sweep the entire building, twice. This action took \n" +
                        "2 hours and nothing extraordinary has happened. Now, there were times when the gadget \n" +
                        "would light up, but it didn’t take long to figure out that this was only because you were standing \n" +
                        "by the elevator or an active computer.\n" +
                        "IV: I would like to retract what I said earlier. I bet people watching is way more exciting than \n" +
                        "IV: this. Hell, I’d rather be watching grass grow than whatever we are supposed to be doing here.\n" +
                        "Suddenly, you hear a loud, blood curdling scream coming from downstairs.\n" +
                        "IV: I retract my retraction. That sounds interesting. Let’s go check it out.\n" +
                        "You rush downstairs and find John standing in the lobby with what you assume to be two other \n" +
                        "members; a guy and a girl. John was currently speaking with the girl.\n" +
                        "John: Can you please calm down and explain what happened?\n" +
                        "The girl is shaking, but she takes a quick breath and begins to speak.\n" +
                        "Female Member: Okay. So, Zack and I were using the Ouija board and we aren’t getting \n" +
                        "Female Member: anything for about 20 minutes. But, then, it spells out the words ‘help me’. Now, I thought Zack\n" +
                        "Female Member: was just messing with me. So, I started asking questions. First, I asked for its name and it \n" +
                        "Female Member: spelled out Bethanie. Then if she was killed and the board went to yes.\n" +
                        "Female Member: Now, at this point I was actually starting to worry that this wasn’t just Zack trying to mess with me.\n" +
                        "John: Alright. So, what happened next?\n" +
                        "Female Member: Well, I wasn’t too sure what to do. So, I just asked how she was killed. Then my neck really started to hurt, so I screamed.\n" +
                        "John: You felt like you were being strangled?\n" +
                        "Female Member: No. It felt like I was stabbed.\n" +
                        "You aren’t too sure whether you believe that girl’s story or not, but you are a little freaked out by\n" +
                        "it. So, you tell John that you are very tired and are going home.\n" +
                        "John: Oh, you’re leaving? Well, I hope you had a good time at least. Also, we have a meeting\n" +
                        "John: next Wednesday if you want to come. Be safe and have a good night.\n\nPress any button to continue...");
                gameState = 39;
            }
            if(e.getSource() == ch_2) {
                pane.setText("With the spirit box in hand, you proceed to sweep the entire building, twice. This took 2 hours\n" +
                        "and nothing extraordinary has happened. Now, there would be an indistinct noise from the \n" +
                        "gadget every now and then, but nothing you could really understand. You are currently \n" +
                        "downstairs. During your investigation, you found a door that leads outside, so you slip out for some fresh air.\n" +
                        "The area behind the building was dark and quiet, except for the constant static noise from the \n" +
                        "spirit box. You go to try and turn the device off, but before you do, you hear something.\n" +
                        "Spirit Box: tststststststststststststststststststststststststsHELPtstststststststsMEtstststststs \n" +
                        "Not quite sure what you heard. You bring the spirit box closer to your ear and listen intensely.\n" +
                        "Spirit Box: tststststststststsNAMEtstststststststststststststststststsBETHANIEtstststststststststs\n" +
                        "Spirit Box: tststsBEARDEDtststststststsMANtststststststststststKILLstststststststststststststst\n" +
                        "Spirit Box: tstststststststststsSTABBEDtstststststststststststststststststststststststststststst\n" +
                        "You couldn’t believe what you were hearing and it was freaking you out. Right as you were \n" +
                        "about to go inside and tell John what you just heard, you hear a blood curdling scream from \n" +
                        "inside the building. Still on edge, you panic and run away back to your dorm.\n\nPress any button to continue...");
                gameState = 39;
            }
        }
        else if(gameState == 38) {
            pane.setText("The time is 6:28 p.m. You went to classes, but, like last time, they did not provide any pertinent \n" +
                    "information. So, you mostly spent class time writing your paper over the crazy dog man you \n" +
                    "confronted earlier today. You enter the meeting room and are greeted by an overwhelming \n" +
                    "crowd of about 6 people. Harper, currently standing at a podium at the front of the room, notices \n" +
                    "you, smiles and approaches to greet you.\n" +
                    "Harper: I’m actually surprised you came Headlights.\n" +
                    "You look at Harper with disbelief.\n" +
                    "Harper: Don’t give me that look. I had over 20 people tell me they would swing by and check\n" +
                    "Harper: us out, but, as you can see, that’s not exactly the case. Anyway, are you ready to give your report?\n" +
                    "Unaware that you would be giving the report orally, you frantically ask about the report she was going to give.\n" +
                    "Harper: Oh that? Yeah, that was just a little fib I told you to make sure you showed up. We do a \n" +
                    "Harper: lot of fibbing here. That being said, I did need someone to demonstrate what we do here. So...\n" +
                    "Once again, you ask why didn’t she just do it.\n" +
                    "Harper: Seriously!? These pure, innocent people aren’t ready for my masterpieces, so I \n" +
                    "thought somebody with a little less experience should do it. So, up you go.\n" +
                    "Suddenly, Harper pushes you towards the podium and all eyes fall on you. Desperate to end the \n" +
                    "awkward silence, you go ahead and read your report about the deranged, canine hermit. Once \n" +
                    "you finish, all 11 of the audience and Harper clap in approval. Following this, Harper points you \n" +
                    "to a seat and begins the meeting. After about 30 minutes, the meeting ends and Harper comes toward you laughing.\n" +
                    "Harper: That was spectacular. Everyone loved your story. So much so, that they all signed up \n" +
                    "Harper: for the club. I mean, you may not talk much, but you sure know how to cook up a story. \n" +
                    "Harper: Although, next time, try to tone it down a little bit. I know I told you that you could lie a little, but \n" +
                    "Harper: try to stay on the side of reality.\n" +
                    "Harper: Anyway, I hope you had a good time and I’ll see you at the next meeting. Same time. Same place.\n\nPress any button to continue...");
            gameState++;
        }
        else if(gameState == 39) {
            pane.setText("Upon entering your dorm room, you notice something was different. Unlike previous nights, your \n" +
                    "roommate was not already in bed. In fact, your roommate was not in the dorm. Of course, you \n" +
                    "quickly shake it off as no big deal. So, you lazily slip into your pajamas. However, with it still \n" +
                    "being rather early. You decide to do something else before going to sleep. What would you like to do?\n" +
                    "Study (Choice 1)\n" +
                    "Play Video Games (Choice 2)\n");
            gameState++;
        }
        else if(gameState == 40) { //Day 6
            if(e.getSource() == ch_1) {
                preparedness+=4;
                prep.setText(preparedness+"/100");
                p_bar.setValue(preparedness);
            }
            else if(e.getSource() == ch_2) {
                san+=3;
                sanity.setText(san+"/100");
                s_bar.setValue(san);
            }
            pane.setText("Day 6: Friday\n\nYou awaken to your alarm, like you have every other morning. Also like the other mornings, you \n" +
                    "get out of bed, stretch, and get ready. The time is 7:24 a.m. and you head out the door.\n" +
                    "IV: I can’t believe it’s already Friday! Time just goes by so fast. I feel like I could cry.\n" +
                    "IV: Now, before you go and make your final decision for the week, I just want you to know that I \n" +
                    "IV: loved every moment I spent this week judging all of your poor choices.\n" +
                    "IV: Oh, and remember. I hope you are satisfied with everything that happened this week \n" +
                    "IV: because if not…, you can just start the game over.\n" +
                    "What would you like to do?\n" +
                    "Go to Class (Choice 1)\n" +
                    "Skip Class (Choice 2)\n");
            gameState++;
        }
        else if(gameState == 41) {
            if(e.getSource() == ch_1) {
                pane.setText("You enter the room where your Calculus class is held. You take a seat in the middle of class and \n" +
                        "wait for class to begin. After a few minutes, your professor enters the room with a large stack of \n" +
                        "papers and begins to speak.\n" +
                        "Dr. Oblonsky: Look at all of these smart, or perhaps just lucky, students that decided to come \n" +
                        "Dr. Oblonsky: to class today. All I will say is that I hope you studied hard like I told you to because this quiz will \n" +
                        "not be easy. So, let’s do this.\n\nPress any button to continue...");
                gameState++;
            }
            if(e.getSource() == ch_2) {
                pane.setText("Game Over\nThank you for playing!\n\nPlay Again(Choice 1)\nQuit(Choice 2)");
                gameState=35;
            }
        }
        else if(gameState == 42) {
            if(e.getSource()==ch_1 || e.getSource() == ch_2){
                //TODO: set bars for prep and san to decide whether they pass
                if(san >= 50 || preparedness >= 20){
                    pane.setText("Congratulations! You passed the quiz!\n\nThank you for playing!\n\nPlay Again(Choice 1)\nQuit(Choice 2)");
                    gameState=35;
                } else{
                    pane.setText("Unfortunately, you failed the quiz! Better luck next time.\n\nThank you for playing!\n\nPlay Again(Choice 1)\nQuit(Choice 2)");
                    gameState=35;
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {

        CS445_GUI_MN s = new CS445_GUI_MN();
        s.setVisible(true);
    }

}

