import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CS445_GUI{
    public static void main(String args[]){
        JFrame main_frame = new JFrame("School of Hard Choices");

        JPanel top_panel = new JPanel();
        JPanel bot_panel = new JPanel(new BorderLayout());
        JPanel labels_panel = new JPanel();
        JPanel choiceButtons_panel = new JPanel();
        JPanel logAndButtons_panel = new JPanel();
        logAndButtons_panel.setLayout(new BoxLayout(logAndButtons_panel, BoxLayout.Y_AXIS));



        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        //game screen
        ImageIcon start = new ImageIcon("D:\\CSCE\\CSCE_445_Project\\game_menu.png");
        JTextPane pane = new JTextPane();
        pane.insertIcon(start);
        pane.setEditable(false);

        //game log
        JLabel log_label = new JLabel("Log");
        JTextArea notebook = new JTextArea(35,20);

        //buttons
        JButton ch_1 = new JButton("Choice 1");
        JButton ch_2 = new JButton("Choice 2");

        //Resources
        JLabel p_label = new JLabel("Preparedness");
        JTextArea prep = new JTextArea(1,5);
        JProgressBar p_bar = new JProgressBar();
        p_bar.setValue(50);
        prep.setEditable(false);
        prep.setText("50/100");

        JLabel s_label = new JLabel("Sanity");
        JTextArea sanity = new JTextArea(1,5);
        JProgressBar s_bar = new JProgressBar();
        s_bar.setValue(50);
        sanity.setEditable(false);
        sanity.setText("50/100");
        
        
        choiceButtons_panel.add(ch_1);
        choiceButtons_panel.add(ch_2);
        
        logAndButtons_panel.add(log_label);
        logAndButtons_panel.add(notebook);
        logAndButtons_panel.add(choiceButtons_panel);

        top_panel.add(pane);
        top_panel.add(logAndButtons_panel, BorderLayout.CENTER);
        
        labels_panel.add(p_label);
        labels_panel.add(p_bar);
        labels_panel.add(prep);
        labels_panel.add(s_label);
        labels_panel.add(s_bar);
        labels_panel.add(sanity);
        
        bot_panel.add(labels_panel, BorderLayout.CENTER);


        main_frame.add(top_panel,BorderLayout.PAGE_START); 
        main_frame.add(bot_panel,BorderLayout.CENTER); 
        main_frame.setSize(screenSize.width,screenSize.height);
        main_frame.setLocationRelativeTo(null);
        main_frame.setVisible(true);
    }
}
