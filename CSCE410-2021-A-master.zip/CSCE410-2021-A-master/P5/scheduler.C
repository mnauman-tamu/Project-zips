/*
 File: scheduler.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "scheduler.H"
#include "thread.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   S c h e d u l e r  */
/*--------------------------------------------------------------------------*/


/*This function is used to basically start the linked list and sets first and last
nodes to null*/
Scheduler::Scheduler() {
  //assert(false);
	first = NULL;
	last = NULL;
  Console::puts("Constructed Scheduler.\n");
}


/*This function is used to make sure that the thread is ready and waiting. It also deletes
 it from the list*/
void Scheduler::yield() {
  //assert(false);
	node* temp = first;
	Thread* tempthread = temp->thread;
	first = first->prev;
	first->next = NULL;
	delete temp;
	Thread::dispatch_to(tempthread);
}


/*This functions is used to add the thread to the list. If there is no list, then it also
creates the list*/
void Scheduler::resume(Thread * _thread) {
  //assert(false);
	if (first != NULL) {
		node* newth = new node;
		newth->next = last;
		last->prev = newth;
		last = newth;
		last->thread = _thread;
	}	
	else {
		node* newth = new node;
		newth->next = NULL;
		newth->prev = NULL;
		newth->thread = _thread;
		first = newth;
		last = newth;
	}
}


/*This function is used to simply call resume on a thread*/
void Scheduler::add(Thread * _thread) {
  //assert(false);
	this->resume(_thread);
}


/*This function is used to iterate through the list and check if the given thread exists
in the list. If the thread is found, then it removes that thread*/
void Scheduler::terminate(Thread * _thread) {
  //assert(false);
	Thread* curr = Thread::CurrentThread();
	if (_thread == curr) {
		this->yield();
	}
	node* tmp = last;
	while (tmp != NULL) {
		if (tmp->thread != _thread) {
			tmp = tmp->next;
		}
		else {
			node* thre = tmp;
			tmp = tmp->next;
			thre->prev->next = thre->next;
			thre->next->prev = thre->prev;
			delete thre;
		}
	}
		
}
