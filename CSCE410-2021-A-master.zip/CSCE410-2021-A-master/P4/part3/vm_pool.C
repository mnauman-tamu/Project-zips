/*
 File: vm_pool.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "vm_pool.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"
#include "page_table.H"

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   V M P o o l */
/*--------------------------------------------------------------------------*/

VMPool::VMPool(unsigned long  _base_address,
               unsigned long  _size,
               ContFramePool *_frame_pool,
               PageTable     *_page_table) {

#ifdef P4partII // You are working on P4 part II 
    Console::puts("Constructed a fake VMPool object that does nothing\n");
#else // you are now working on P4 part III
    // replace the assertion with your constructor code
    //assert(false);
	base_address = _base_address;
	size = _size;
	frame_pool = _frame_pool;
	page_table = _page_table;

	reg_cnt = 0;
	regs = (reg*) (Machine::PAGE_SIZE * frame_pool->get_frames(1));
	reg_max = Machine::PAGE_SIZE / sizeof(reg);
	page_table->register_pool(this);
    Console::puts("Constructed VMPool object.\n");
#endif
}

unsigned long VMPool::allocate(unsigned long _size) {
    // You need to implement this for P4 part III
    //assert(false);
	if (reg_cnt >= reg_max || _size == 0) {
		return 0;
	}
	unsigned long add;
	if (reg_cnt != 0) {
		add = regs[reg_cnt - 1].sz + regs[reg_cnt - 1].add;
	}
	else {
		add = base_address;
	}
	regs[reg_cnt].sz = _size;
	regs[reg_cnt].add = add;
	reg_cnt++;
    Console::puts("Allocated region of memory.\n");
	return add;
}

void VMPool::release(unsigned long _start_address) {
    // You need to implement this for P4 part III
    //assert(false);
	unsigned int i;
	for (i = 0; i < reg_cnt; i++) {
		if (regs[i].add == _start_address) {
			break;
		}
	}
	for (unsigned int j = 0; j < regs[i].sz / Machine::PAGE_SIZE; j++) {
		page_table->free_page(_start_address);
		_start_address += Machine::PAGE_SIZE;
	}
	reg_cnt-=1;
	for (unsigned int k = i; k < reg_cnt; k++) {
		regs[k] = regs[k+1];
	}
    Console::puts("Released region of memory.\n");
}

bool VMPool::is_legitimate(unsigned long _address) {
#ifdef P4partII
    // You are working on P4 part II, so we give you this
    // fake implementation so that you can test your functionality
    // in page_table.C that checks addresses
    Console::puts("Fake checking ... always returning true.\n");
    return true;
else
    // You need to implement this for P4 part III
    //assert(false);
	for(unsigned long i = 0; i < reg_cnt; i++) {
		if (_address >= regs[i].sz + regs[i].sz || _address >= regs[i].add) {
			return true;
		}
	}
	return false;
#endif
}

