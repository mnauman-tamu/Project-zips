#include "assert.H"
#include "exceptions.H"
#include "console.H"
#include "paging_low.H"
#include "page_table.H"

PageTable * PageTable::current_page_table = NULL;
unsigned int PageTable::paging_enabled = 0;
ContFramePool * PageTable::kernel_mem_pool = NULL;
ContFramePool * PageTable::process_mem_pool = NULL;
unsigned long PageTable::shared_size = 0;


void PageTable::init_paging(ContFramePool * _kernel_mem_pool,
                            ContFramePool * _process_mem_pool,
                            const unsigned long _shared_size)
{
   //assert(false);
	//Console::puts("A\n");
	kernel_mem_pool = _kernel_mem_pool;
	process_mem_pool = _process_mem_pool;
	shared_size = _shared_size;
   Console::puts("Initialized Paging System\n");
}

PageTable::PageTable()
{
    //Console::puts("B\n");
   unsigned long directory_frame = kernel_mem_pool->get_frames(1);
	unsigned long table_frame = kernel_mem_pool->get_frames(1);
	unsigned long curr_add = 0;
	//page_directory stores the address of the directory page
	page_directory = (unsigned long*) (PAGE_SIZE * directory_frame);
	unsigned long* table = (unsigned long*) (PAGE_SIZE * table_frame);
	page_directory[0] = (unsigned long) table;
	page_directory[0] = (unsigned long) page_directory[0] | 3;	//Setting to supervisor level with read/write
	//maps 4 MB directly 	
	for (unsigned int i = 0; i <= 1023; i++) {
		table[i] = curr_add | 3; //Setting to supervisor level with read/write
		curr_add += 4096;
	}
	for (unsigned int i = 1; i <= 1023; i++) {
		page_directory[i] = 0 | 2;
	}
   Console::puts("Constructed Page Table object\n");
}


void PageTable::load()
{
	//Console::puts("C\n");
   write_cr3((unsigned long)page_directory);
	current_page_table = this;
   Console::puts("Loaded page table\n");
}

void PageTable::enable_paging()
{
   //assert(false);
	//write_cr3((unsigned long)current_page_table->page_directory);
	//Console::puts("D\n");
	unsigned long old = read_cr0();
	write_cr0(old | (2^31));
	paging_enabled = 1;
   Console::puts("Enabled paging\n");
}

void PageTable::handle_fault(REGS * _r)
{
    // replace the assertion with your implementation for this method,
    // BUT YOU ALSO NEED TO MAKE A SMALL CHANGE to
    // the method. Look at the file README-change-needed-handle_fault.txt
    // 
    // Your implementation can be either:
    // (a) the one from P3 (i.e., you did not implement the "recursive trick"
    //     that allows for inner page tables to reside in virtual memory)
    // or
    // (b) your new PageTable implementation that supports large address
    //     spaces (i.e., it allocates inner page tables from
    //     the process pool)
    // 
	   unsigned long addr = read_cr2(); /* you already had something like
                                    ** this at the begining of your
                                    ** implementation for handle_fault 
                                    */

   /* Now the suggested code. It uses output utilities from utils.H 
   ** You put this code after reading the faulting address, and before
   ** the code that is handling the fault.
   */
   if (!current_page_table->check_address(addr)) {
       Console::puts("check_address failed for address: ");
       Console::putui(addr);
       Console::puts(" (this in hexa ");
       char hexastr[9];
       ulong2hexstr(addr, hexastr);
       Console::puts(hexastr);
       Console::puts(")\n");
       abort();
   }
	
	//cr3 is where the page_directory information is stored
        unsigned long * directory = (unsigned long *) read_cr3();
	//cr2 is the page fault address is stored    	
	unsigned int curr = read_cr2();
    	unsigned long outer = curr >> 22;
	unsigned long inner = (curr >> 12) & 0x3FF;
	unsigned long * new_table;
	//changed my mind, I think this is easier
	if(outer == 0x3FF) {
		outer = inner;
		inner = (curr >> 2) & 0x3FF;
	}
    	if((directory[outer] & 1)) {
		//If there is a table, then map to the inner page table where the fault happened
		new_table = (unsigned long *)(directory[outer] & 0xFFFFF00);
 		new_table[inner] = (process_mem_pool->get_frames(1)*PAGE_SIZE) | 3;
    	}
    	else {
		//If there is no table available, then get an available frame and undate the page table
        	new_table = (unsigned long *)(kernel_mem_pool->get_frames(1) * PAGE_SIZE);
        	directory[outer] = (unsigned long) new_table | 3;

		for(unsigned int i = 0; i < 1024; i++) {
		    	new_table[i] = 0;
		}
        	new_table[inner] = (process_mem_pool->get_frames(1) * PAGE_SIZE) | 3;
    	}

    Console::puts("handled page fault\n");
}

bool PageTable::check_address(unsigned long address)
{
    // you need to implement this for P4 Part II.
    // It returns true if legitimate, false otherwise.
    // You check for legitimacy using VMPool::is_legitimate,
    // which you will implement for real in P4 Part III.
    // For part II, we give you a fake implementation
    // in vm_pool.C for you to use for  now.
    //assert(false);
	for(int i=0; i<shared_size; i++) {
		if((vm_pools[i]->is_legitimate(address)) == false){
			return false;
		}
	}
    return true; // you need to implement this
}

void PageTable::register_pool(VMPool * _vm_pool)
{
    // you need to implement this for P4 Part II.
    //assert(false);
	vm_pools[shared_size] = _vm_pool;
	shared_size++;
    Console::puts("registered VM pool\n");
}
	
void PageTable::free_page(unsigned long _page_no) {
    // you need to implement this for P4 Part II.
    //assert(false);
	unsigned long d_ind = _page_no >> 22;
	unsigned long t_ind = (_page_no >> 12) | 0x3FF;
	unsigned long t_add = (d_ind << 12) | (1023 >> 22);
	unsigned long* c_tab = (unsigned long*) t_add;
	unsigned long p_add = 0xFFFFFFFC & c_tab[t_ind];
	unsigned long p_fno = p_add / PAGE_SIZE;
	process_mem_pool->release_frames(p_fno);
	unsigned long oldcr3 = read_cr3();
	write_cr3(oldcr3);
    Console::puts("freed page\n");
}
