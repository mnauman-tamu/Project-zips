#include "assert.H"
#include "exceptions.H"
#include "console.H"
#include "paging_low.H"
#include "page_table.H"

PageTable * PageTable::current_page_table = NULL;
unsigned int PageTable::paging_enabled = 0;
ContFramePool * PageTable::kernel_mem_pool = NULL;
ContFramePool * PageTable::process_mem_pool = NULL;
unsigned long PageTable::shared_size = 0;



void PageTable::init_paging(ContFramePool * _kernel_mem_pool,
                            ContFramePool * _process_mem_pool,
                            const unsigned long _shared_size)
{
   //assert(false);
	//Console::puts("A\n");
	kernel_mem_pool = _kernel_mem_pool;
	process_mem_pool = _process_mem_pool;
	shared_size = _shared_size;
   Console::puts("Initialized Paging System\n");
}

PageTable::PageTable()
{
	//Console::puts("B\n");
   unsigned long directory_frame = kernel_mem_pool->get_frames(1);
	unsigned long table_frame = kernel_mem_pool->get_frames(1);
	unsigned long curr_add = 0;
	//page_directory stores the address of the directory page
	page_directory = (unsigned long*) (PAGE_SIZE * directory_frame);
	unsigned long* table = (unsigned long*) (PAGE_SIZE * table_frame);
	page_directory[0] = (unsigned long) table;
	page_directory[0] = (unsigned long) page_directory[0] | 3;	//Setting to supervisor level with read/write
	//maps 4 MB directly 	
	for (unsigned int i = 0; i <= 1023; i++) {
		table[i] = curr_add | 3; //Setting to supervisor level with read/write
		curr_add += 4096;
	}
	for (unsigned int i = 1; i <= 1023; i++) {
		page_directory[i] = 0 | 2;
	}
   Console::puts("Constructed Page Table object\n");
}


void PageTable::load()
{
	//Console::puts("C\n");
   write_cr3((unsigned long)page_directory);
	current_page_table = this;
   Console::puts("Loaded page table\n");
}

void PageTable::enable_paging()
{
   //assert(false);
	//write_cr3((unsigned long)current_page_table->page_directory);
	//Console::puts("D\n");
	unsigned long old = read_cr0();
	write_cr0(old | (2^31));
	paging_enabled = 1;
   Console::puts("Enabled paging\n");
}

void PageTable::handle_fault(REGS *_r) {
	//cr3 is where the page_directory information is stored
        unsigned long * directory = (unsigned long *) read_cr3();
	//cr2 is the page fault address is stored    	
	unsigned int curr = read_cr2();
    	unsigned long outer = curr >> 22;
	unsigned long inner = (curr >> 12) & 0x3FF;
	unsigned long * new_table;
    	if((directory[outer] & 1)) {
		//If there is a table, then map to the inner page table where the fault happened
		new_table = (unsigned long *)(directory[outer] & 0xFFFFF00);
 		new_table[inner] = (process_mem_pool->get_frames(1)*PAGE_SIZE) | 3;
    	}
    	else {
		//If there is no table available, then get an available frame and undate the page table
        	new_table = (unsigned long *)(kernel_mem_pool->get_frames(1) * PAGE_SIZE);
        	directory[outer] = (unsigned long) new_table | 3;

		for(unsigned int i = 0; i < 1024; i++) {
		    	new_table[i] = 0;
		}
        	new_table[inner] = (process_mem_pool->get_frames(1) * PAGE_SIZE) | 3;
    	}

    Console::puts("handled page fault\n");
}
