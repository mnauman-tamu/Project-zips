package com.group3;

public class WarGame {

    public static void main(String[] args) {
	    new MainMenu();
    }
}
