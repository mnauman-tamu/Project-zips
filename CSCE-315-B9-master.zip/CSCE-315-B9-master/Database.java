import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import java.util.*;



class Database {
	private static final String url = "jdbc:postgresql://csce-315-db.engr.tamu.edu:5432/csce315_section902_b9";
	private static final String user = "mnauman";
	private static final String password = "927008027";
	private Connection conn;
	private String output;

	public Database() {
		try {
			// call methods that might throw SQLException
			conn = connect();
		} catch (SQLException e) {
			// do something appropriate with the exception, *at least*:
			e.printStackTrace();
		}

	}

	//Connects to the server
	public Connection connect() throws SQLException {
		System.out.println("Trace: Attempting connection");
		Connection connection = DriverManager.getConnection(url, user, password);
		if (connection != null) {
			System.out.println("Connected to PostgreSQL server successfully!");
			return connection;
		} else {
			System.out.println("Failed to connect to PostgreSQL server");
		}
		return null;
	}

	public Connection getConnection() throws SQLException {
		return conn;
	}
	public String getBName(String b1, Connection conn) throws SQLException{
		String query = "select name from public.\"Businesses\" where business_id = \'" + b1 + "\' limit 1;";
		ResultSet rs = sendPureQuery(query, conn);
		rs.next();
		return rs.getString("name");
	}
	public String getUName(String u1, Connection conn) throws SQLException{
		String query = "select name from public.\"User\" where user_id = \'" + u1 + "\' limit 1;";
		ResultSet rs = sendPureQuery(query, conn);
		rs.next();
		return rs.getString("name");
	}
	public String getLinkedUser2(String b1, String b2, Connection conn) throws SQLException{
		String query = "select user_id, count(distinct business_id) c from public.\"ReducedAdvancedReviews\" where business_id = \'" + b1 + "\' or business_id = \'" + b2 + "\' group by user_id order by c DESC limit 1;";
		ResultSet rs = sendPureQuery(query, conn);
		rs.next();
		return getUName(rs.getString("user_id"), conn);
	}
	public String getLinkedUser(String biz1s, String biz2s, Connection conn2) throws SQLException{
		String query1 = "SELECT review_id, user_id, business_id FROM public.\"ReducedAdvancedReviews\" WHERE business_id LIKE \'" + biz1s + "\'";//enter in first business id in carrot brackets

		Statement stmt = null;
		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query1);
		ResultSetMetaData rsmd = rs.getMetaData();
		Set<String> biz1 = new HashSet<>();
		System.out.println("GETTING BUSINESS 1 IDS");
		while(rs.next()){
			for(int i = 1; i <= rsmd.getColumnCount(); ++i){
				if(!biz1.contains(rs.getString(2))){
					biz1.add(rs.getString(2));
				}
			}
		}

		String query2 = "SELECT review_id, user_id, business_id FROM public.\"ReducedAdvancedReviews\" WHERE business_id LIKE \'" + biz2s + "\'";//enter in second business id in carrot brackets


		ResultSet rs2 = stmt.executeQuery(query2);
		ResultSetMetaData rsmd2= rs2.getMetaData();
		Set<String> biz2 = new HashSet<>();
		System.out.println("GETTING BUSINESS 2 IDS ");
		while(rs2.next()){
			for(int i = 1; i <= rsmd2.getColumnCount(); ++i){
				if(!biz2.contains(rs2.getString(2))){
					biz2.add(rs2.getString(2));
				}
			}
		}

		
		//List<String> dblUsers = new ArrayList<>();
		
		String userID = "";
		for(String user : biz1){
			if(biz2.contains(user)){//add if any of reviewers on first biz also reviewed second
				//dblUsers.add(user);
				userID = user;
				break;
			}
		}
		
		if(userID.equals("")){
			return "No user found";
		}

		String query3 = "SELECT user_id, name FROM public.\"User\" WHERE user_id LIKE \'" + userID + "\'";
		
		rs = stmt.executeQuery(query3);

		String retUser = "";
		if(rs.next())
			retUser = rs.getString(2);
		if(retUser.equals("")){
			System.out.println("No user found");
			return "No User found";
		}
		
		System.out.println("USERNAME: " + retUser + " USER_ID: " + userID);
		return retUser;

	}

	//Sends the query to the server DO NOT CHANGE THIS 
	public void sendQuery(String query, Connection conn2) throws SQLException {
		//System.out.println("Running query");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			//Print one row
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				output = output + rsmd.getColumnLabel(i) + ": " + rs.getString(i) + ", "; //Print one element of a row
			}
			output += "\n";//Move to the next line to print the next row.

		}
		// while (rs.next()) //Cycles through each row
		// {
		// 	for(int i = 0; i < listOfColumns.size(); i++) //Cycles through all the user desired columns for one row
		// 	{
		//   	output = output + " " + listOfColumns.get(i) + ": " + rs.getString(listOfColumns.get(i)) + ", ";
		// 	}
		//     output += "\n";
		// }

		printOutput();
	}

	public void sendQuery2(String query, Connection conn2) throws SQLException {
		//System.out.println("Running query");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			//Print one row
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				output = output + rs.getString(i); //Print one element of a row
			}
			//output += "\n";//Move to the next line to print the next row.

		}
		// while (rs.next()) //Cycles through each row
		// {
		// 	for(int i = 0; i < listOfColumns.size(); i++) //Cycles through all the user desired columns for one row
		// 	{
		//   	output = output + " " + listOfColumns.get(i) + ": " + rs.getString(listOfColumns.get(i)) + ", ";
		// 	}
		//     output += "\n";
		// }

		printOutput();
	}

	public void sendQueryForArraylist(String query, Connection conn2, ArrayList<String> arr) throws SQLException {
		System.out.println("Running sendQueryForArraylist");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			//Print one row
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				//output = output + rsmd.getColumnLabel(i) + ": " + rs.getString(i) + ", "; //Print one element of a row
				arr.add(rs.getString(1));
			}

		}
	}
	
	public void Q4sendQueryForArraylist(String query, Connection conn2, ArrayList<Q4BusinessEntity> arr) throws SQLException {
		System.out.println("Running Q4sendQueryForArraylist");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		String bizzName = "";
		String bizzID = "";
		String lat = "";
		String lon = "";
		String stars = "-1";
		String city = "";
		String state = "";
		while (rs.next()) {
			//Print one row
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				//output = output + rsmd.getColumnLabel(i) + ": " + rs.getString(i) + ", "; //Print one element of a row
				//arr.add(rs.getString(1));
				bizzName = rs.getString(1);
				bizzID = rs.getString(2);
				lat = rs.getString(3);
				lon = rs.getString(4);
				stars = rs.getString(5);
				city = rs.getString(6);
				state = rs.getString(7);
			}
			arr.add(new Q4BusinessEntity(bizzName, bizzID, Double.parseDouble(lat), Double.parseDouble(lon), Double.parseDouble(stars), city, state));
		}
	}

	public ResultSet sendPureQuery(String query, Connection conn2) throws SQLException {
		//System.out.println("Running query");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		return stmt.executeQuery(query);
	}
	
	public void Q4sendQueryForArraylistLatLon(String query, Connection conn2, ArrayList<Q4BusinessEntity> arr, int index) throws SQLException {
		//System.out.println("Running Q4sendQueryForArraylistLatLon()");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			//Print one row
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				//output = output + rsmd.getColumnLabel(i) + ": " + rs.getString(i) + ", "; //Print one element of a row
				//arr.add(rs.getString(1));
				Double lat = Double.parseDouble(rs.getString(1));
				//System.out.println("Converted " + rs.getString(1) + " to " + lat);
				Double lon = Double.parseDouble(rs.getString(2));
				arr.get(index).setLat(lat);
				arr.get(index).setLon(lon);
			}
		}
	}
	
	public String Q4sendQueryForString(String query, Connection conn2) throws SQLException {
		System.out.println("Running Q4sendQueryForString()");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			//Print one row
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				output = output + rsmd.getColumnLabel(i) + ": " + rs.getString(i) + ", "; //Print one element of a row
			}
			output += "\n";//Move to the next line to print the next row.
		}
		return output;
	}
	
	public void Q4AggregateCount(String query, Connection conn, ArrayList<Q4BusinessEntity> businesses) throws SQLException
	{
		System.out.println("Running Q4AggregateCount()");
		output = "";
		Statement stmt = null;
		String bizzName;		
		String bizzCount; //Number of locations that bizzName has
		
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			bizzName = rs.getString(1);
			bizzCount = rs.getString(2);
			//System.out.println(bizzName + ":" + bizzCount);
			
			for(int i = 0; i < businesses.size(); i++) {
				if(businesses.get(i).getBusinessName().equals(bizzName)) {
					businesses.get(i).setNumOfLocations(Integer.parseInt(bizzCount));
				}
			}
		}

	}
	
	public String sendQueryForBizzID(String query, Connection conn2) throws SQLException {
		System.out.println("Running sendQueryForBizzID()");
		String bizzID = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			//Print one row
			bizzID = bizzID + rs.getString(1); //Print one element of a row
		}
		
		//System.out.println("LogExiting: sendQueryForBizzID()- bizzID: " + bizzID);
		return bizzID;
	}
	
	public String sendQueryGetCount(String query, Connection conn2) throws SQLException {
		//System.out.println("Running query");
		output = "";
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			//Print one row
			output = output + rs.getString(1); //Print one element of a row
		}
		return output;
	}
	
	//DO NOT CHANGE THIS
	public String sendOutput() {
		//System.out.println("Top");
		return output;
	}
	
	//DO NOT CHANGE THIS
	private void printOutput() {
		System.out.println(output);
	}

	//DO NOT CHANGE THIS
	public String sendExportQuery(String query, Connection conn2) throws SQLException {
		//System.out.println("Running query");
		StringBuilder sb = new StringBuilder();
		Statement stmt = null;

		stmt = conn2.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		//Print header row
		for (int j = 1; j <= rsmd.getColumnCount(); j++) {
			sb.append(rsmd.getColumnLabel(j) + ", ");
		}
		sb.delete(sb.length() - 2, sb.length());
		sb.append("\n");
		while (rs.next()) {
			//Print one row
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				//Print one element of a row
				sb.append(rs.getString(i) + ", ");
			}
			sb.delete(sb.length() - 2, sb.length());
			sb.append("\n");//Move to the next line to print the next row.

		}

		return sb.toString();
	}

	public String sendExportQuery2(ArrayList<String> q2, Connection conn2, int query) throws SQLException {
		//System.out.println("Running query");
		StringBuilder sb = new StringBuilder();
		Statement stmt = null;

		stmt = conn2.createStatement();
		//Print header row
		if (query == 1) {
			sb.append("Shortest Chain of Patrons\n");
			sb.append(q2.get(0));
		}
		if (query == 2) {
			sb.append("user_id, Avg Stars, Num of Comments, Avg Useful, Avg Funny, Avg Cool, Sum Useful, Sum Funny, Sum Cool, ");

			sb.delete(sb.length() - 2, sb.length());
			sb.append("\n");
			for (int i = 1; i < 10; i++) {
				sb.append(q2.get(i) + ", ");
			}
			sb.delete(sb.length() - 2, sb.length());
		}
		if (query == 3) {
			sb.append("name, city, state\n");
			String s = q2.get(0);
			String[] str = s.split(",");
			for(String k: str) {
				System.out.println(k);
				k = k.substring(k.indexOf(":") + 2);
				sb.append(k);
				sb.append(", ");
				System.out.println(k);
			}
		}
		if (query == 4) {
			sb.append("Name, business_id, number_of_tips");
			sb.append("\n");
			String s = q2.get(0);
			String[] str = s.split(",");
			for(String k: str) {
				System.out.println(k);
				k = k.substring(k.indexOf(":") + 2);
				sb.append(k);
				sb.append(", ");
				System.out.println(k);
			}
		}
		if (query == 5) {
			sb.append("City");
			sb.append("\n");
			sb.append(q2.get(0));
		}

		return sb.toString();
	}
}








