

new way, fall 2020   From cmd 
javac jdbcpostgreSQLGUI.java
javac App.java

java -cp .;postgresql-42.2.8.jar jdbcpostgreSQLGUI
java -cp .;postgresql-42.2.8.jar App

or from powershell:
javac jdbcpostgreSQLGUI.java

java -cp ".;postgresql-42.2.8.jar" jdbcpostgreSQLGUI