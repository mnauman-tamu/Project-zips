import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

//Phase 4 Question 3
public class Phase4Question3 
{
	Connection conn;
	Database database;
	
	public Phase4Question3(Connection conInput, Database dbInput)
	{
		conn = conInput;
		database = dbInput;
	}
	
	public String runQuestion3(String stateSelected) throws SQLException
	{
		System.out.println("Running Question 3");
		ArrayList<Q4BusinessEntity> ArrQ4BusinessEntities = new ArrayList<Q4BusinessEntity>();
		
		//Get all businesses from the Business Table from the desired state and returns NAME, ID, LAT, LON, STARS. Good states: SC, AZ, NC, OH, PA
		//String stateSelected = "OH";
		String queryCommand1 = "SELECT name,business_id, latitude,longitude,stars,city,state FROM public.\"AdvancedBusinesses\" WHERE state LIKE \'" + stateSelected + "\' and (resteraunt_is_take_out = TRUE or resteraunt_is_take_out = FALSE)";
		System.out.println("QueryCommand1= " + queryCommand1);

		database.Q4sendQueryForArraylist(queryCommand1, conn, ArrQ4BusinessEntities);
		for(int i = 0; i < ArrQ4BusinessEntities.size(); i++) { //Outputs every business's NAME, ID, LAT, LON, STARS, CITY, STATE [O8]
			//ArrQ4BusinessEntities.get(i).outputEight();
		}
		
		//Filter out all businesses that only have less than 2 locations NEW VERSION
		String queryCommand2;
		queryCommand2 = "SELECT name, COUNT(*) FROM public.\"AdvancedBusinesses\" WHERE stars > 3.5 AND state LIKE \'" + stateSelected + "\' GROUP BY name";
		System.out.println("QueryCommand2: " + queryCommand2);
		database.Q4AggregateCount(queryCommand2, conn, ArrQ4BusinessEntities);
		for(int i = 0; i < ArrQ4BusinessEntities.size(); i++) {
			if(ArrQ4BusinessEntities.get(i).getNumOfLocations() < 2) {
				ArrQ4BusinessEntities.remove(i);
				i--;
			}
		}
		for(int i = 0; i < ArrQ4BusinessEntities.size(); i++) { //Outputs every business's NAME, ID, LAT, LON, STARS,CITY,STATE [O8]. Same as above except this has only desired franchises
			//ArrQ4BusinessEntity.get(i).outputEight();
		}
		

		ArrayList<Q4FranchiseEntity> ArrQ4FranchiseEntity = new ArrayList<Q4FranchiseEntity>();
		//Calculate the max distance between the latitudes and longitudes of a franchise�s two locations and then removes all franchises with an average rating below 3.5 stars		
		for(int i = 0; i < ArrQ4BusinessEntities.size(); i++) {
			//System.out.println("Trace");
			String bizzName = ArrQ4BusinessEntities.get(i).getBusinessName();
			String bizzID = ArrQ4BusinessEntities.get(i).getBusinessID();
			Double bizzLat = ArrQ4BusinessEntities.get(i).getLat();
			Double bizzLon = ArrQ4BusinessEntities.get(i).getLon();
			Double bizzStars = ArrQ4BusinessEntities.get(i).getStars();
			String bizzCity = ArrQ4BusinessEntities.get(i).getCity();
			String bizzState = ArrQ4BusinessEntities.get(i).getState();
			
			int franchMaxDistancesIndex = checkAlreadyInsertedIntofrenchMaxDistanceIndex(bizzName, ArrQ4FranchiseEntity);
			if(franchMaxDistancesIndex < 0) { //FranchiseMaxDistance class not made yet for this franchise
				//System.out.println("LogTrace: if(temp < 0)");
				ArrQ4FranchiseEntity.add(new Q4FranchiseEntity(bizzName, bizzID, bizzLat, bizzLon, bizzStars, bizzCity, bizzState));
			}
			else { //Compares the new location's lat and lon with previous same franchise locations and calculate the max distance
				//System.out.println("LogTrace: if(!(temp < 0))- i: " + frenchMaxDistancesIndex);
				ArrQ4FranchiseEntity.get(franchMaxDistancesIndex).addBusiness(ArrQ4BusinessEntities.get(i)); 
			}
		}		
		for(int i = 0; i < ArrQ4FranchiseEntity.size(); i++) { //Removes Franchises that have an average rating below 3.5
			if(ArrQ4FranchiseEntity.get(i).getFranchiseAverages() < 3.5) {
				ArrQ4FranchiseEntity.remove(i);
				i--;
			}
		}
		for(int i = 0; i < ArrQ4FranchiseEntity.size(); i++) { //Debug loop for checking Franchises ArrayList
			//ArrQ4FranchiseEntity.get(i).printFranchiseAveragesAndTop5Locations(); //Debug print statement
		}
		
		//String maxFranchiseName = craftMaxDistanceFranchiseQuery(ArrQ4FranchiseEntity); //this query command gets 5 locations from the franchise with the furthest location's distance
		//String queryCommand4 = "SELECT name,stars,latitude,longitude,state FROM public.\"AdvancedBusinesses\" WHERE name LIKE \'" + scrubName(maxFranchiseName) + "\' AND state LIKE \'" + stateSelected + "\'LIMIT 5;";
		//System.out.println("Query Command 4: " + queryCommand4);
		//String finalOutput = database.Q4sendQueryForString(queryCommand4, conn);
		//System.out.println(finalOutput);
		
		//Rank the franchises based on max distances and output 5 franchises and all their locations
		bubbleSort(ArrQ4FranchiseEntity);
		int count = Math.min(5, ArrQ4FranchiseEntity.size());
		String result = "";
		for(int i = 0; i < count; i++) { //FINAL OUTPUT
			result += ArrQ4FranchiseEntity.get(i).printFranchiseAveragesAndTop2Locations(); //Debug print statement
		}
		System.out.println("Finished Question 3");

		return result;

	}
	private void bubbleSort(ArrayList<Q4FranchiseEntity> arr)
	{
		Q4FranchiseEntity temp;
		int length = arr.size(); 
        for (int i = 0; i < length - 1; i++) 
        {
        	for (int j = 0; j < length - i - 1; j++) 
        	{
        		if (arr.get(j).getMaxDistance() < arr.get(j+1).getMaxDistance()) 
                { 
                    // swap arr[j+1] and arr[j] 
                    temp = arr.get(j); 
                    arr.set(j, arr.get(j+1)); //arr[j] = arr[j+1]; 
                    arr.set(j+1, temp);		//arr[j+1] = temp; 
                } 
        	}
        }
	}
	
	private String craftMaxDistanceFranchiseQuery(ArrayList<Q4FranchiseEntity> franchiseMaxDistances)
	{
		double maxDistance = -1;
		int maxIndex = -1;
		for(int i = 0; i < franchiseMaxDistances.size(); i++) {
			if(franchiseMaxDistances.get(i).getMaxDistance() > maxDistance) {
				maxDistance = franchiseMaxDistances.get(i).getMaxDistance();
				maxIndex = i;
			}
		}
		return franchiseMaxDistances.get(maxIndex).getFranchiseName();
	}
	
	private int checkAlreadyInsertedIntofrenchMaxDistanceIndex(String str, ArrayList<Q4FranchiseEntity> franchMaxDistance)
	{
		//System.out.println("LogEntering checkAlreadyInserted()- bizzName: " + str + " franchMaxDistance.size(): " + franchMaxDistance.size());
		for(int i = 0; i < franchMaxDistance.size(); i++) {
			if(str.equals(franchMaxDistance.get(i).getFranchiseName())) {
				//System.out.println("LogExiting: checkAlreadyInserted()- return: " + i);
				return i;
			}
		}
		//System.out.println("LogExiting: checkAlreadyInserted()- return: -1");
		return -1;
	}
	
	private static String scrubName(String str) // Example: "Pete's Burgers" -> "Pete\'s Burgers"
	{
		for(int i = 0; i < str.length(); i++)
		{
			if(str.charAt(i) == '\'')
			{
				//System.out.println("Char at: " + str.charAt(i));
				str = str.substring(0, i) + "\'" + str.substring(i, str.length());
				i++;
			}
		}
		return str;
	}
}

class Q4FranchiseEntity //Every franchise has one of this class
{
	private String franchiseName;
	//private ArrayList<Double> arrLocationStars = new ArrayList<Double>(); //Every location's stars from the franchise are stored here
	//private ArrayList<Double> arrLocationLat = new ArrayList<Double>(); //Every franchise's locations are stored here
	//private ArrayList<Double> arrLocationLon = new ArrayList<Double>(); //Every franchise's locations are stored here
	private double maxDistance;
	private ArrayList<Q4BusinessEntity> arrBusinesses = new ArrayList<Q4BusinessEntity>(); //This is a list of Franchise only businesses
	
	public Q4FranchiseEntity(String name, String firstBizzID, double firstLat, double firstLon, double firstStars, String firstCity, String firstState)
	{
		franchiseName = name;
		maxDistance = -1.0;
		
		//arrLocationLat.add(firstLat);
		//arrLocationLon.add(firstLon);
		//arrLocationStars.add(stars);
		arrBusinesses.add(new Q4BusinessEntity(name, firstBizzID, firstLat, firstLon, firstStars, firstCity, firstState));
	}
	
	public String getFranchiseName()
	{
		return franchiseName;
	}
	
	public void addBusiness(Q4BusinessEntity business)
	{
		boolean maxChanged = false;
		Q4BusinessEntity temp = null; 
		int tempIndex = -1;
		//System.out.println("LogEntering: recordMaxDistance()- arrLat.size(): " + arrLat.size() + ", arrLon.size(): " + arrLon.size());
		for(int i = 0; i < arrBusinesses.size(); i++) {
			double distLat = business.getLat() - arrBusinesses.get(i).getLat(); //Distance formula: x1-x2
			double distLon = business.getLon() - arrBusinesses.get(i).getLon(); //Distance formula: y1-y2
			if(calculateDistance(distLat, distLon) > maxDistance) {
				maxChanged = true;
				tempIndex = i;
				temp = arrBusinesses.get(i);
				maxDistance = calculateDistance(distLat, distLon);
			}
		}		
		//arrLocationLat.add(bizzLat);
		//arrLocationLon.add(bizzLon);
		//arrLocationStars.add(bizzStars);
		if(maxChanged) {
			arrBusinesses.set(tempIndex, arrBusinesses.get(0));
			arrBusinesses.set(0, temp);
			arrBusinesses.add(0, business); //If there is a max change, then prioritize the two locations with max distance to the front
		}
		else {	
			arrBusinesses.add(business); //If not max change, then put the new business at the end of the line
		}
	}
	
	public double getMaxDistance()
	{
		return maxDistance;
	}
	
	private double calculateDistance(double distLat, double distLon)
	{
		double latSquared = distLat * distLat; // Distance formula: (x1-x2) squared
		double lonSquared = distLon * distLon; // Distance formula: (y1-y2) squared
		double sum = latSquared + lonSquared; //Distance formula: (x1-x2) squared + (y1-y2) squared
		double distance = Math.sqrt(sum); 
		return distance;
	}
	
	public Double getFranchiseAverages()
	{
		double sum = 0;
		int count = arrBusinesses.size();
		for(int i = 0; i < count; i++) {
			sum += arrBusinesses.get(i).getStars();
		}
		return sum/count;
	}
	
	public void printFranchiseAverages()
	{
		System.out.println("Franchise Name: " + franchiseName + ", Franchise Avg Stars: " + getFranchiseAverages());
	}
	
	public String printFranchiseAveragesAndTop2Locations()
	{
		System.out.println(franchiseName + " Franchise Avg Stars: " + getFranchiseAverages());
		//int count = Math.min(5, arrBusinesses.size()); //The max location the Franchise will output is 5
		String res = "";
		for(int i = 0; i < 2; i++) {
			String bizzName = arrBusinesses.get(i).getBusinessName();
			String bizzCity = arrBusinesses.get(i).getCity();
			String bizzState = arrBusinesses.get(i).getState();
			System.out.println("Business Name: " + bizzName + ", City: " + bizzCity + " , State: " + bizzState);
			res += "Business Name: " + bizzName + ", City: " + bizzCity + " , State: " + bizzState + "\n";
		}

		return res;
	}
}

class Q4BusinessEntity //Every franchise location has one of this class
{
	private String businessName;
	private String businessID;
	private int numOfLocations;
	private double lat;
	private double lon;
	private double stars;
	private String city;
	private String state;

	
	public Q4BusinessEntity(String bizzName, String bizzID, Double latitude, Double longitude, Double starInput, String cityInput, String stateInput)
	{
		businessName = bizzName;
		businessID = bizzID;
		lat = latitude;
		lon = longitude;
		stars = starInput;
		city = cityInput;
		state = stateInput;
	}
	
	public Q4BusinessEntity(String str)
	{
		businessName = str;
	}
	
	public void setBusinessID(String str)
	{
		businessID = str;
	}
	
	public void setNumOfLocations(int num) 
	{
		numOfLocations = num;
	}
	
	public void setLat(double num)
	{
		lat = num;
	}
	
	public void setLon(double num)
	{
		lon = num;
	}
	
	public String getBusinessName()
	{
		return businessName;
	}
	
	public String getBusinessID()
	{
		return businessID;
	}
	
	public int getNumOfLocations()
	{
		return numOfLocations;
	}
	
	public double getLat()
	{
		return lat;
	}
	
	public double getLon()
	{
		return lon;
	}
	
	public double getStars()
	{
		return stars;
	}
	
	public String getCity()
	{
		return city;
	}
	
	public String getState()
	{
		return state;
	}
	
	public void outputTwo()
	{
		System.out.println("[O2]Q4BusinessEntity- Business Name: " + businessName + ", Business ID: " + businessID);
	}
	
	public void outputThree()
	{
		System.out.println("[O3]Q4BusinessEntity- Business Name: " + businessName + ", Business ID: " + businessID + ", # of Locations: " + numOfLocations);
	}
	
	public void outputFive()
	{
		System.out.println("[O5]Q4BusinessEntity- Bizz Name: " + businessName + ", Bizz ID: " + businessID + ", # of Locs: " + numOfLocations + ", Lat: " + lat + ", Lon: " + lon);
	}
	
	public void outputSix()
	{		
		System.out.println("[O6]Q4BusinessEntity- Bizz Name: " + businessName + ", Bizz ID: " + businessID + ", # of Locs: " + numOfLocations + ", Lat: " + lat + ", Lon: " + lon + ", Stars: " + stars);
	}
	
	public void outputEight()
	{	
		System.out.println("[O8]Q4BusinessEntity- Bizz Name: " + businessName + ", Bizz ID: " + businessID + ", # of Locs: " + numOfLocations + ", Lat: " + lat + ", Lon: " + lon + ", Stars: " + stars + ", City: " + city + ", State: " + state);
	}
	
	public void outputFinal(ArrayList<Q4FranchiseEntity> franchMaxDistances)
	{
		double maxDist = -1;
		for(int i = 0; i < franchMaxDistances.size(); i++) {
			if(franchMaxDistances.get(i).getFranchiseName().equals(this.businessName))
				maxDist = franchMaxDistances.get(i).getMaxDistance();
		}
		
		System.out.println("[O6]Q4BusinessEntity- Bizz Name: " + businessName + ", Bizz ID: " + businessID + ", # of Locs: " + numOfLocations + ", Lat: " + lat + ", Lon: " + lon + ", Max Dist: " + maxDist);
	}
}