public class dbSetup {
    public static final String user = "mnauman";
    public static final String pswd = "927008027";
}
