import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class Test {
	
	static Database database;
	public static void main(String[] args) throws SQLException
	{
		database = new Database();
		Connection conn = database.getConnection();
		
		runQuestionFour(conn);
	}

	private static void runQuestionFour(Connection conn) throws SQLException
	{
		System.out.println("Running Question Four");
		//array[String] businesses = SELECT (name) FROM �public�.Business WHERE city = given;
		ArrayList<String> businesses = new ArrayList <String>();
		String citySelected = "Dallas";
		String stateSelected = "NC"; //REPLACE THIS LINE SO THAT IT REFLECTS THE USER'S DESIRED STATE
		String queryCommand = "SELECT name FROM public.\"AdvancedBusinesses\" WHERE city LIKE \'" + citySelected + "\' AND state LIKE \'" + stateSelected + "\' LIMIT 50"; //THE FINAL VERSION WILL HAVE USER REPLACE stateSelected
		database.sendQueryForArraylist(queryCommand, conn, businesses);
		
		for (int i = 0; i < businesses.size(); i++) 
		{
			//System.out.println("preBusinesses: " + businesses.get(i));
		}
		//deletes franchises
		for (int i = 0; i < businesses.size(); i++) 
		{
			if(numberOfLocations(businesses.get(i), conn) > 1)
			{
				//businesses.remove(getIndexOf(business)) //arraylist func
				//System.out.println(businesses.get(i) + " IS A FRANCHISE");
				businesses.remove(i);
				i--;
			}			
		}
		for (int i = 0; i < businesses.size(); i++) 
		{
			//System.out.println("postBusinesses: " + businesses.get(i));
		}
		
		
		//outputArraylist(businesses);
		/*
		for (business : businesses) {
			//Somehow find the business_id of the business and save as b_id
			Int count = COUNT (*) FROM �public�.Tips WHERE business_id = b_id;
			business = (String) count + �  � + business; //To sort them easily later
		}
		businesses.sort(); //hopefully that�s a function*/ 
		
		ArrayList<BusinessEntity> businessEntities = new ArrayList<BusinessEntity>();
		for(int i = 0; i < businesses.size(); i++) //Populates the businessEntites Arraylist with non-franchise names
		{
			//System.out.println("Adding to businessEntities: " + businesses.get(i));
			businessEntities.add (new BusinessEntity(businesses.get(i)));
		}
		
		for(int i = 0; i < businessEntities.size(); i++)
		{
			String bizzName = businessEntities.get(i).getBusinessName();
			bizzName = scrubName(bizzName);
			queryCommand = "SELECT business_id FROM public.\"AdvancedBusinesses\" WHERE name = \'" + bizzName + "\';"; 
			//System.out.println("Final queryCommand for(businessEntities.size())= " + queryCommand);
			String bizzID = database.sendQueryForBizzID(queryCommand, conn);
			businessEntities.get(i).setBusinessID(bizzID);
		}
		for(int i = 0; i < businessEntities.size(); i++)
		{
			//System.out.println("LogCheck: Name- " + businessEntities.get(i).getBusinessName() + ", BusinessID- " + businessEntities.get(i).getBusinessID());
			
			//Get the number of tips for each Business ID
			String bizzID = businessEntities.get(i).getBusinessID();
			queryCommand = "SELECT COUNT(business_id) FROM public.\"Tips\" WHERE business_id LIKE \'" + bizzID + "\';";
			System.out.println("Final queryCommand for counting tips= " + queryCommand);
			String numTips = database.sendQueryGetCount(queryCommand, conn);
			businessEntities.get(i).setNumOfTips(Integer.parseInt(numTips));
			
			//System.out.println("LogCheck: Name- " + businessEntities.get(i).getBusinessName() + ", BusinessID- " + businessEntities.get(i).getBusinessID() + " , Number of Tips: " + businessEntities.get(i).getNumOfTips());
		}
		
		//time to rank the ArrayList based on Number of Tips descending
		bubbleSort(businessEntities);
		
		//Print out final product
		for(int i = 0; i < businessEntities.size(); i++)
		{
			System.out.println("LogCheck: Name- " + businessEntities.get(i).getBusinessName() + ", BusinessID- " + businessEntities.get(i).getBusinessID() + " , Number of Tips: " + businessEntities.get(i).getNumOfTips());
		}
		System.out.println("Finished Question Four");
	}
	
	private static int numberOfLocations(String name, Connection conn) throws SQLException
	{
		//Count(*) FROM �public.Business WHERE name LIKE business;
		//System.out.println("LogTrace: name= " + name);
		name = scrubName(name);
		String queryCommand = "SELECT COUNT(name) FROM public.\"AdvancedBusinesses\" WHERE name LIKE \'" + name + "\';";
		//System.out.println("Final queryCommand numberOfLocations()= " + queryCommand);
		String output = database.sendQueryGetCount(queryCommand, conn);
		int num = Integer.parseInt(output);
		//System.out.println("Number of " + name + " locations: " + num);
		return num;
	}
	
	private static String scrubName(String str) // Example: "Pete's Burgers" -> "Pete\'s Burgers"
	{
		for(int i = 0; i < str.length(); i++)
		{
			if(str.charAt(i) == '\'')
			{
				//System.out.println("Char at: " + str.charAt(i));
				str = str.substring(0, i) + "\'" + str.substring(i, str.length());
				i++;
			}
		}
		return str;
	}
	private static void outputArraylist(ArrayList<String> arr)
	{
		for(int i = 0; i < arr.size(); i++)
		{
			System.out.println(arr.get(i));
		}
	}

	private static void bubbleSort (ArrayList<BusinessEntity> arr)
	{
		BusinessEntity temp;
		int length = arr.size(); 
        for (int i = 0; i < length - 1; i++) 
        {
        	for (int j = 0; j < length - i - 1; j++) 
        	{
        		if (arr.get(j).getNumOfTips() < arr.get(j+1).getNumOfTips()) 
                { 
                    // swap arr[j+1] and arr[j] 
                    temp = arr.get(j); 
                    arr.set(j, arr.get(j+1)); //arr[j] = arr[j+1]; 
                    arr.set(j+1, temp);		//arr[j+1] = temp; 
                } 
        	}
        }
	}
}

class BusinessEntity
{
	private String businessName;
	private String businessID;
	private int numOfTips;
	
	public BusinessEntity(String str)
	{
		businessName = str;
	}
	
	public void setBusinessID(String str)
	{
		businessID = str;
	}
	
	public void setNumOfTips(int num)
	{
		numOfTips = num;
	}
	
	public String getBusinessName()
	{
		return businessName;
	}
	
	public String getBusinessID()
	{
		return businessID;
	}
	
	public int getNumOfTips()
	{
		return numOfTips;
	}
}
