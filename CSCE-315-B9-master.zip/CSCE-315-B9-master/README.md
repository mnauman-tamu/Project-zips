Howdy! To compile and run:

javac Phase4Question3.java
javac Database.java
javac App.java

java -cp .;postgresql-42.2.8.jar App
