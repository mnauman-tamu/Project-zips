//package dbsetup;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.beans.Statement;
import java.sql.Connection;

public class JDBCPostgreSQLConnect
{
    //jdbc:postgresql://127.0.0.1:49945/browser/
    private final String url = "jdbc:postgresql://csce-315-db.engr.tamu.edu/csce315_section902_b9";
    private final String user = "rwlui9";
    private final String password = "227007359";

    public Connection connect() throws SQLException
    {
        System.out.println("Trace: Attempting connection");
        Connection connection= DriverManager.getConnection(url,user, password);
        if(connection != null) {
            System.out.println("Connected to PostgreSQL server successfully!");
            return connection;
        }else {
            System.out.println("Failed to connect to PostgreSQL server");
        }
        return null;
    }

    public void getSampleBusinessData(Connection con) throws SQLException
    {
        Statement stmt = null;
        String query = "SELECT * FROM public.\"Businesses\"\r\n" +
                "ORDER BY business_id ASC LIMIT 100";

        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        while (rs.next())
        {
            String businessName = rs.getString("name");
            double stars = rs.getDouble("stars");
            int reviewCount = rs.getInt("review_count");
            boolean isRestaurantTakeOut = rs.getBoolean("restaurant_is_take_out");
            System.out.println("Business Name: " + businessName + ", Stars: " + stars + ", Review Count: " + reviewCount
                    + ", Offers Take Out?: " + isRestaurantTakeOut);
        }
    }
}
